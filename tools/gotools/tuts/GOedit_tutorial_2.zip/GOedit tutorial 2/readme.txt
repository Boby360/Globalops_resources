fetched from http://wayback.archive.org/web/20030209215501*/http://www.barking-dog.com/goedit/tutorial2/
by fallout <falloutdc at gmail dot dom> www.globalops.tk
