PLANETSHOGO
------------------------------------------------------------------------------------------
LEVEL EDITING DOCUMENTATION
------------------------------------------------------------------------------------------


Thank you for downloading the Level Editing Documentation. It contains the 
DEdit level editor documentation and the Shogo Objects documentation released 
by Monolith Productions, Inc. and some tutorials. For the latest tutorials, visit 
http://www.planetshogo.com/editing regularly. Happy level editing!!


Requirements
----------------------------
The documentation can be viewed on any computer with Windows 95/98 or 
Windows NT 4.0/5.0  and Microsoft Internet Explorer installed.


Installation
----------------------------
Included in the zip file is an executable file (hhupd.exe) which will update the HTML Help 
viewer on your computer to the latest version (1.2). Before you view the documentation
it is recommended that you run this exe file first so that your version of HTML Help can be 
updated.

You can get the latest version of this viewer and the complete installation file directly 
from Microsoft at http://www.microsoft.com/workshop/author/htmlhelp/default.asp

After installing/updating HTML Help, you can just click on the 
"Level Editing Documentation.chm" file to view it.



