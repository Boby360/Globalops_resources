#You should not modify or redistribute this file, as you may break compatibility with future versions of Noesis.
#This module also defines several classes which are integrated with the Noesis native binary Python module, so changing those will cause things to explode.

#There is a lot of instance/type checking in here, because that's just the way things are. You aren't meant to be able to provide custom interfaces for
#these types. If you want to encapsulate them somehow, you should just hold a reference to them in your own custom class/object instead.

import noesis
import struct

#rapi methods should only be used during handler callbacks
import rapi

#in case overriding central unpacking/packing functions becomes desirable
noeUnpack = struct.unpack
noeUnpackFrom = struct.unpack_from
noePack = struct.pack

NOESEEK_ABS = 0
NOESEEK_REL = 1
NOE_BIGENDIAN = 1
NOE_LITTLEENDIAN = 0

#class wrapper to parse through some bytes using the struct unpacker
class NoeUnpacker:
	def __init__(self, data):
		self.byteOfs = 0
		self.data = data
		self.dataSize = len(data)

	def read(self, fmtStr):
		readBytes = struct.calcsize(fmtStr)
		if (self.byteOfs+readBytes) > self.dataSize:
			noesis.doException("Tried to read off end of data array.")
		readData = noeUnpackFrom(fmtStr, self.data, self.byteOfs)
		self.byteOfs += readBytes
		return readData

	def seek(self, addr, isRelative = NOESEEK_ABS):
		if isRelative == NOESEEK_ABS:
			self.byteOfs = addr
		else:
			self.byteOfs += addr
		return self.byteOfs

	def tell(self):
		return self.byteOfs

	def checkOverrun(self, size):
		if self.byteOfs+size > self.dataSize:
			return 1
		return 0


#Universal binary reader/writer, also handles reading/writing data off of byte-aligned boundaries.
#example use:
#	writer = NoeBitStream()
#	writer.writeString("Hello. I'm coming to get you.")
#	open("somefile.bin", "wb").write(writer.getBuffer())
class NoeBitStream(NoeUnpacker):
	def __init__(self, data = None, bigEndian = NOE_LITTLEENDIAN):
		self.data = data
		if data is None: #set up for writing
			self.h = noesis.allocType("writeStream")
		else: #set up for reading
			self.h = noesis.allocType("readStream", self.data)
			self.dataSize = len(self.data)
		self.setEndian(bigEndian)

	def getBuffer(self, startOfs = None, endOfs = None):
		if startOfs is not None and endOfs is not none:
			return noesis.bsGetBufferSlice(self.h, startOfs, endOfs)
		else:
			return noesis.bsGetBuffer(self.h)
	def getSize(self):
		return noesis.bsGetSize(self.h)
	def setOffset(self, ofs):
		noesis.bsSetOfs(self.h, ofs)
	def getOffset(self):
		return noesis.bsGetOfs(self.h)
	def setEndian(self, bigEndian = NOE_LITTLEENDIAN):
		return noesis.bsSetEndian(self.h, bigEndian)
	def checkEOF(self):
		return self.getOffset() >= self.getSize()

	def writeBytes(self, data):
		return noesis.bsWriteBytes(self.h, data)
	def writeBits(self, val, numBits):
		return noesis.bsWriteBits(self.h, val, numBits)
	def writeBool(self, val):
		return noesis.bsWriteBool(self.h, val)
	def writeByte(self, val):
		return noesis.bsWriteByte(self.h, val)
	def writeUByte(self, val):
		return noesis.bsWriteUByte(self.h, val)
	def writeShort(self, val):
		return noesis.bsWriteShort(self.h, val)
	def writeUShort(self, val):
		return noesis.bsWriteUShort(self.h, val)
	def writeInt(self, val):
		return noesis.bsWriteInt(self.h, val)
	def writeUInt(self, val):
		return noesis.bsWriteUInt(self.h, val)
	def writeFloat(self, val):
		return noesis.bsWriteFloat(self.h, val)
	def writeHalfFloat(self, val):
		return noesis.bsWriteUShort(self.h, noesis.encodeFloat16(val))
	def writeString(self, str, writeTerminator = 1):
		return noesis.bsWriteString(self.h, str, writeTerminator)

	def readBytes(self, numBytes):
		return noesis.bsReadBytes(self.h, numBytes)
	def readBits(self, numBits):
		return noesis.bsReadBits(self.h, numBits)
	def readBool(self):
		return noesis.bsReadBool(self.h)
	def readByte(self):
		return noesis.bsReadByte(self.h)
	def readUByte(self):
		return noesis.bsReadUByte(self.h)
	def readShort(self):
		return noesis.bsReadShort(self.h)
	def readUShort(self):
		return noesis.bsReadUShort(self.h)
	def readInt(self):
		return noesis.bsReadInt(self.h)
	def readUInt(self):
		return noesis.bsReadUInt(self.h)
	def readFloat(self):
		return noesis.bsReadFloat(self.h)
	def readHalfFloat(self):
		return noesis.getFloat16(noesis.bsReadUShort(self.h))
	def readString(self):
		return noesis.bsReadString(self.h)
	def readline(self):
		return noesis.bsReadLine(self.h)

	#provide interfaces for the NoeUnpacker (better to use the base class if you want to use this functionality exclusively)
	def toUnpacker(self):
		self.byteOfs = self.getOffset()
	def fromUnpacker(self):
		self.setOffset(self.byteOfs)
	def read(self, fmtStr):
		self.toUnpacker(); r = noeSuper(self).read(fmtStr); self.fromUnpacker(); return r
	def seek(self, addr, isRelative = NOESEEK_ABS):
		self.toUnpacker(); r = noeSuper(self).seek(addr, isRelative); self.fromUnpacker(); return r
	def tell(self):
		self.toUnpacker(); r = noeSuper(self).tell(); self.fromUnpacker(); return r
	def checkOverrun(self, size):
		self.toUnpacker(); r = noeSuper(self).checkOverrun(size); self.fromUnpacker(); return r


#3-component Vector
class NoeVec3:
	def __init__(self, vec3 = (0.0, 0.0, 0.0)):
		self.vec3 = vec3
		noesis.vec3Validate(self)
	def __getitem__(self, index):
		return self.vec3[index]
	def __setitem__(self, index, value):
		if isinstance(self.vec3, tuple):
			self.vec3 = noeTupleToList(self.vec3)
		self.vec3[index] = value
	def __repr__(self):
		return repr(self.vec3)
	def __len__(self):
		return len(self.vec3)
	def binaryCompare(self, other):
		return self.vec3[0] == other.vec3[0] and self.vec3[1] == other.vec3[1] and self.vec3[2] == other.vec3[2]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def __add__(self, other):
		return noesis.vec3Add(self, other)
	def __sub__(self, other):
		return noesis.vec3Sub(self, other)
	def __mul__(self, other):
		if isinstance(other, NoeVec3):
			return noesis.vec3Mul(self, other)
		elif isinstance(other, NoeMat43):
			return noesis.mat43TransformPoint(other, self)
		elif isinstance(other, NoeQuat):
			return noesis.quatTransformPoint(other, self)
		elif isinstance(other, list):
			return noesis.vec3Mul(self, other)
		else:
			return NoeVec3([self.vec3[0]*other, self.vec3[1]*other, self.vec3[2]*other])
	def __div__(self, other):
		return noesis.vec3Div(self, other)
	def __truediv__(self, other):
		return noesis.vec3Div(self, other)
	def __neg__(self):
		return NoeVec3([-self.vec3[0], -self.vec3[1], -self.vec3[2]])

	def dot(self, other):			#returns float
		return noesis.vec3Dot(self, other)
	def cross(self, other):			#returns vector
		return noesis.vec3Cross(self, other)
	def length(self):			#returns float
		return noesis.vec3Len(self)
	def lengthSq(self):			#returns float
		return noesis.vec3LenSq(self)
	def normalize(self):			#returns vector
		return noesis.vec3Norm(self)
	def lerp(self, other, fraction):	#returns vector
		return noesis.vec3Lerp(self, other, fraction)

	def toAngles(self):
		return noesis.vec3ToAngles(self)
	def toVec4(self):
		return noesis.vec3ToVec4(self)
	def toMat43(self):
		return noesis.vec3ToMat43(self)
	def toAnglesDirect(self):
		return NoeAngles([self.vec3[0], self.vec3[1], self.vec3[2]])
	def toBytes(self):			#returns bytearray
		return noesis.vec3ToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.vec3FromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.vec3


#4-component Vector
class NoeVec4:
	def __init__(self, vec4 = (0.0, 0.0, 0.0, 0.0)):
		self.vec4 = vec4
		noesis.vec4Validate(self)
	def __getitem__(self, index):
		return self.vec4[index]
	def __setitem__(self, index, value):
		if isinstance(self.vec4, tuple):
			self.vec4 = noeTupleToList(self.vec4)
		self.vec4[index] = value
	def __repr__(self):
		return repr(self.vec4)
	def __len__(self):
		return len(self.vec4)
	def binaryCompare(self, other):
		return self.vec4[0] == other.vec4[0] and self.vec4[1] == other.vec4[1] and self.vec4[2] == other.vec4[2] and self.vec4[3] == other.vec4[3]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def __add__(self, other):
		return noesis.vec4Add(self, other)
	def __sub__(self, other):
		return noesis.vec4Sub(self, other)
	def __mul__(self, other):
		if isinstance(other, NoeVec4):
			return noesis.vec4Mul(self, other)
		elif isinstance(other, NoeMat43):
			return noesis.mat43TransformVec4(other, self)
		elif isinstance(other, NoeMat44):
			return noesis.mat44TransformVec4(other, self)
		elif isinstance(other, list):
			return noesis.vec4Mul(self, other)
		else:
			return NoeVec4([self.vec4[0]*other, self.vec4[1]*other, self.vec4[2]*other, self.vec4[3]*other])
	def __div__(self, other):
		return noesis.vec4Div(self, other)
	def __truediv__(self, other):
		return noesis.vec4Div(self, other)
	def __neg__(self):
		return NoeVec4([-self.vec4[0], -self.vec4[1], -self.vec4[2], -self.vec4[3]])

	def dot(self, other):			#returns float
		return noesis.vec4Dot(self, other)
	def length(self):			#returns float
		return noesis.vec4Len(self)
	def lengthSq(self):			#returns float
		return noesis.vec4LenSq(self)
	def normalize(self):			#returns vector
		return noesis.vec4Norm(self)
	def lerp(self, other, fraction):	#returns vector
		return noesis.vec4Lerp(self, other, fraction)

	def toVec3(self):
		return noesis.vec4ToVec3(self)
	def toBytes(self):			#returns bytearray
		return noesis.vec4ToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.vec4FromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.vec4


#Euler angles (can and occasionally is also used to store radians, see also noesis.g_flDegToRad/noesis.g_flRadToDeg constants)
class NoeAngles:
	def __init__(self, angles = (0.0, 0.0, 0.0)):
		self.vec3 = angles
		noesis.anglesValidate(self)
	def __getitem__(self, index):
		return self.vec3[index]
	def __setitem__(self, index, value):
		if isinstance(self.vec3, tuple):
			self.vec3 = noeTupleToList(self.vec3)
		self.vec3[index] = value
	def __repr__(self):
		return repr(self.vec3)
	def __len__(self):
		return len(self.vec3)
	def binaryCompare(self, other):
		return self.vec3[0] == other.vec3[0] and self.vec3[1] == other.vec3[1] and self.vec3[2] == other.vec3[2]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def __add__(self, other):
		return noesis.vec3Add(self, other).toAnglesDirect()
	def __sub__(self, other):
		return noesis.vec3Sub(self, other).toAnglesDirect()
	def __mul__(self, other):
		if isinstance(other, NoeAngles):
			return noesis.vec3Mul(self, other).toAnglesDirect()
		elif isinstance(other, list):
			return noesis.vec3Mul(self, other).toAnglesDirect()
		else:
			return NoeAngles([self.vec3[0]*other, self.vec3[1]*other, self.vec3[2]*other])
	def __div__(self, other):
		return noesis.vec3Div(self, other).toAnglesDirect()
	def __truediv__(self, other):
		return noesis.vec3Div(self, other).toAnglesDirect()
	def __neg__(self):
		return NoeAngles([-self.vec3[0], -self.vec3[1], -self.vec3[2]])

	def angleMod(self, f):			#returns angles
		return noesis.anglesMod(self, f)
	def normalize180(self):			#returns angles
		return noesis.anglesNormalize180(self)
	def normalize360(self):			#returns angles
		return noesis.anglesNormalize360(self)
	def angleVectors(self):			#returns mat43
		return noesis.anglesAngleVectors(self)
	def lerp(self, other, fraction):	#returns angles
		return noesis.vec3Lerp(self, other, fraction).toAnglesDirect()
	def alerp(self, other, degrees):	#returns angles
		return noesis.anglesALerp(self, other, degrees)

	def toVec3(self):
		return noesis.anglesToVec3(self)
	def toMat43(self):
		return noesis.anglesToMat43(self)
	def toMat43_XYZ(self, yFlip = 1):
		return noesis.anglesToMat43_XYZ(self, yFlip)
	def toQuat(self):
		return noesis.anglesToQuat(self)
	def toVec3Direct(self):
		return NoeVec3([self.vec3[0], self.vec3[1], self.vec3[2]])
	def toBytes(self):			#returns bytearray
		return noesis.vec3ToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.vec3FromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.vec3


identityMat43Tuple = ( NoeVec3((1.0, 0.0, 0.0)), NoeVec3((0.0, 1.0, 0.0)), NoeVec3((0.0, 0.0, 1.0)), NoeVec3((0.0, 0.0, 0.0)) )
identityMat44Tuple = ( NoeVec4((1.0, 0.0, 0.0, 0.0)), NoeVec4((0.0, 1.0, 0.0, 0.0)), NoeVec4((0.0, 0.0, 1.0, 0.0)), NoeVec4((0.0, 0.0, 0.0, 1.0)) )


#4x3 matrix
class NoeMat43:
	def __init__(self, mat43 = identityMat43Tuple):
		self.mat43 = mat43
		noesis.mat43Validate(self)
	def __getitem__(self, index):
		return self.mat43[index]
	def __setitem__(self, index, value):
		if isinstance(self.mat43, tuple):
			self.mat43 = noeTupleToList(self.mat43)
		self.mat43[index] = value
	def __repr__(self):
		return repr(self.mat43)
	def __len__(self):
		return len(self.mat43)
	def binaryCompare(self, other):
		return self.mat43[0] == other.mat43[0] and self.mat43[1] == other.mat43[1] and self.mat43[2] == other.mat43[2] and self.mat43[3] == other.mat43[3]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def __add__(self, other):
		return noesis.mat43Add(self, other)
	def __sub__(self, other):
		return noesis.mat43Sub(self, other)
	def __mul__(self, other):
		if isinstance(other, NoeMat43):
			return noesis.mat43Mul(self, other)
		elif isinstance(other, NoeVec3):
			return noesis.mat43TransformPoint(self, other)
		elif isinstance(other, NoeVec4):
			return noesis.mat43TransformVec4(self, other)
		elif isinstance(other, list):
			return noesis.mat43Mul(self, other)
		else:
			return NoeMat43([self.mat43[0]*other, self.mat43[1]*other, self.mat43[2]*other, self.mat43[3]*other])
	def __neg__(self):
		return NoeMat43([-self.mat43[0], -self.mat43[1], -self.mat43[2], -self.mat43[3]])

	def transformPoint(self, other):	#returns vec3
		return noesis.mat43TransformPoint(self, other)
	def transformNormal(self, other):	#returns vec3
		return noesis.mat43TransformNormal(self, other)
	def transformVec4(self, other):		#returns vec4
		return noesis.mat43TransformVec4(self, other)
	def transpose(self):			#returns mat43
		return noesis.mat43Transpose(self)
	def inverse(self):			#returns mat43
		return noesis.mat43Inverse(self)
	def orthogonalize(self):		#returns mat43
		return noesis.mat43Orthogonalize(self)
	def isSkewed(self):			#returns 1 if skewed, otherwise 0
		return noesis.mat43IsSkewed(self)
	def rotate(self, degrees, rotAngles, transposeRot = 0):	#returns mat43
		return noesis.mat43Rotate(self, degrees, rotAngles, transposeRot)
	def translate(self, trnVector):			#returns mat43
		return noesis.mat43Translate(self, trnVector)
	def lerp(self, other, fraction):		#returns mat43
		return noesis.mat43Lerp(self, other, fraction)
	def slerp(self, other, fraction):		#returns mat43
		return noesis.mat43SLerp(self, other, fraction)

	def toQuat(self):
		return noesis.mat43ToQuat(self)
	def toAngles(self):
		return noesis.mat43ToAngles(self)
	def toMat44(self):
		return noesis.mat43ToMat44(self)
	def toBytes(self):			#returns bytearray
		return noesis.mat43ToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.mat43FromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.mat43


#4x4 matrix
#NoeMat44 operations (including to and from NoeMat43) have rows and columns swapped
class NoeMat44:
	def __init__(self, mat44 = identityMat44Tuple):
		self.mat44 = mat44
		noesis.mat44Validate(self)
	def __getitem__(self, index):
		return self.mat44[index]
	def __setitem__(self, index, value):
		if isinstance(self.mat44, tuple):
			self.mat44 = noeTupleToList(self.mat44)
		self.mat44[index] = value
	def __repr__(self):
		return repr(self.mat44)
	def __len__(self):
		return len(self.mat44)
	def binaryCompare(self, other):
		return self.mat44[0] == other.mat44[0] and self.mat44[1] == other.mat44[1] and self.mat44[2] == other.mat44[2] and self.mat44[3] == other.mat44[3]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def __add__(self, other):
		return noesis.mat44Add(self, other)
	def __sub__(self, other):
		return noesis.mat44Sub(self, other)
	def __mul__(self, other):
		if isinstance(other, NoeMat44):
			return noesis.mat44Mul(self, other)
		elif isinstance(other, NoeVec4):
			return noesis.mat44TransformVec4(self, other)
		elif isinstance(other, list):
			return noesis.mat44Mul(self, other)
		else:
			return NoeMat44([self.mat44[0]*other, self.mat44[1]*other, self.mat44[2]*other, self.mat44[3]*other])
	def __neg__(self):
		return NoeMat44([-self.mat44[0], -self.mat44[1], -self.mat44[2], -self.mat44[3]])

	def transformVec4(self, other):		#returns vec4
		return noesis.mat44TransformVec4(self, other)
	def transpose(self):			#returns mat44
		return noesis.mat44Transpose(self)
	def inverse(self):			#returns mat44
		return noesis.mat44Inverse(self)
	def rotate(self, degrees, rotAngles):	#returns mat44
		return noesis.mat44Rotate(self, degrees, rotAngles)
	def translate(self, trnVector):		#returns mat44
		return noesis.mat44Translate(self, trnVector)

	def toMat43(self):
		return noesis.mat44ToMat43(self)
	def toBytes(self):			#returns bytearray
		return noesis.mat44ToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.mat44FromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.mat44


#packed quaternion
class NoeQuat3:
	def __init__(self, quat3 = (0.0, 0.0, 0.0)):
		self.vec3 = quat3
		noesis.quat3Validate(self)
	def __getitem__(self, index):
		return self.vec3[index]
	def __setitem__(self, index, value):
		if isinstance(self.vec3, tuple):
			self.vec3 = noeTupleToList(self.vec3)
		self.vec3[index] = value
	def __repr__(self):
		return repr(self.vec3)
	def __len__(self):
		return len(self.vec3)
	def binaryCompare(self, other):
		return self.vec3[0] == other.vec3[0] and self.vec3[1] == other.vec3[1] and self.vec3[2] == other.vec3[2]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def toQuat(self):
		return noesis.quat3ToQuat(self)
	def toBytes(self):			#returns bytearray
		return noesis.quat3ToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.quat3FromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.vec3


#quaternion
class NoeQuat:
	def __init__(self, quat = (0.0, 0.0, 0.0, 1.0)):
		self.quat = quat
		noesis.quatValidate(self)
	def __getitem__(self, index):
		return self.quat[index]
	def __setitem__(self, index, value):
		if isinstance(self.quat, tuple):
			self.quat = noeTupleToList(self.quat)
		self.quat[index] = value
	def __repr__(self):
		return repr(self.quat)
	def __len__(self):
		return len(self.quat)
	def binaryCompare(self, other):
		return self.quat[0] == other.quat[0] and self.quat[1] == other.quat[1] and self.quat[2] == other.quat[2] and self.quat[3] == other.quat[3]
	def __eq__(self, other):
		return self.binaryCompare(other)
	def __ne__(self, other):
		return not self.binaryCompare(other)

	def __add__(self, other):
		return noesis.quatAdd(self, other)
	def __sub__(self, other):
		return noesis.quatSub(self, other)
	def __mul__(self, other):
		if isinstance(other, NoeQuat):
			return noesis.quatMul(self, other)
		elif isinstance(other, NoeVec3):
			return noesis.quatTransformPoint(self, other)
		elif isinstance(other, NoeVec4):
			return noesis.quatTransformVec4(self, other)
		elif isinstance(other, list):
			return noesis.quatMul(self, other)
		else:
			return NoeQuat([self.quat[0]*other, self.quat[1]*other, self.quat[2]*other, self.quat[3]*other])
	def __neg__(self):
		return NoeQuat([-self.quat[0], -self.quat[1], -self.quat[2], -self.quat[3]])

	def transformPoint(self, other):	#returns vec3
		return noesis.quatTransformPoint(self, other)
	def transformNormal(self, other):	#returns vec3
		return noesis.quatTransformNormal(self, other)
	def transpose(self):			#returns quat
		return noesis.quatTranspose(self)
	def length(self):			#returns float
		return noesis.quatLen(self)
	def normalize(self):			#returns quat
		return noesis.quatNormalize(self)
	def lerp(self, other, fraction):	#returns quat
		return noesis.quatLerp(self, other, fraction)
	def slerp(self, other, fraction):	#returns quat
		return noesis.quatSLerp(self, other, fraction)

	def toQuat3(self):
		return noesis.quatToQuat3(self)
	def toMat43(self, transposed = 0):
		return noesis.quatToMat43(self, transposed)
	def toMatAngles(self):
		return noesis.quatToAngles(self)
	def toBytes(self):			#returns bytearray
		return noesis.quatToBytes(self)
	def fromBytes(otherBytes, bigEnd = NOE_LITTLEENDIAN):	#returns type built from binary
		return noesis.quatFromBytes(otherBytes, bigEnd)
	def getStorage(self):			#returns raw storage (list, tuple, etc)
		return self.quat


#texture object
#for supported pixel types, look at constants exposed by noesis module, such as NOESISTEX_RGB24, NOESISTEX_RGBA32, NOESISTEX_DXT1, etc.
class NoeTexture:
	def __init__(self, name, width, height, pixelData, pixelType = noesis.NOESISTEX_RGBA32):
		self.name = name
		self.width = width
		self.height = height
		self.pixelData = pixelData
		self.pixelType = pixelType
		self.flags = 0
	def __repr__(self):
		return "(NoeTexture:" + " w:" + repr(self.width) + " h:" + repr(self.height) + " p:" + repr(self.pixelType) + " f:" + repr(self.flags) + " n:" + repr(self.name) + ")"

	def setFlags(flags):
		self.flags = flags


#material object
class NoeMaterial:
	def __init__(self, name, texName):
		self.name = name
		self.setTexture(texName)

	#texture names must match the name of a texture in the corresponding texture list to be applied
	def setTexture(self, texName):
		self.texName = texName

	def setNormalTexture(self, texName):
		self.nrmTexName = texName

	def setSpecularTexture(self, texName):
		self.specTexName = texName

	def setOpacityTexture(self, texName):
		self.opacTexName = texName

	def setFlags(self, flags, disableLighting = 0):
		self.flags = flags
		self.disableLighting = disableLighting

	def setSkipRender(self, skipRender):
		self.skipRender = skipRender

	#uses gl blend string names (GL_ONE, GL_SRC_COLOR, etc)
	def setBlendMode(self, blendSrc, blendDst):
		self.blendSrc = blendSrc
		self.blendDst = blendDst

	#enables/disables default blending
	def setDefaultBlend(self, defaultBlend):
		self.defaultBlend = defaultBlend

	def setAlphaTest(self, alphaVal):
		self.alphaTest = alphaVal

	def setDiffuseColor(self, clr = NoeVec4([1.0, 1.0, 1.0, 1.0])):
		self.diffuseColor = clr

	#4th component is the exponent
	def setSpecularColor(self, clr = NoeVec4([1.0, 1.0, 1.0, 8.0])):
		self.specularColor = clr


#material and texture lists must be provided to the Noesis API in one of these containers (for the purpose of possible future extension)
class NoeModelMaterials:
	#must be initialized with lists of NoeTexture and NoeMaterial
	def __init__(self, texList, matList):
		noesis.validateListType(texList, NoeTexture)
		noesis.validateListType(matList, NoeMaterial)
		self.matList = matList
		self.texList = texList


#model bone. bone hierarchy is defined by matching bone name to parentName.
#index is used to ensure order and match to vertex weights. it is possible to have gaps in your bone list by specifying out-of-order indices.
#NOTE: you don't need to specify parentIndex as long as you specify parentName. parentIndex is optional.
class NoeBone:
	def __init__(self, index, name, matrix, parentName = None, parentIndex = -1):
		self.index = index
		self.name = name
		self.setMatrix(matrix)
		self.parentName = parentName
		self.parentIndex = parentIndex #parent index may be specified instead of parentName, if it's more convenient. this is an index corresponding to self.index, and not the position in the list.
	def __repr__(self):
		return "(NoeBone:" + repr(self.index) + "," + self.name + "," + repr(self.parentName) + "," + repr(self.parentIndex) + ")"

	def setMatrix(self, matrix):
		if not isinstance(matrix, NoeMat43):
			noesis.doException("Invalid type provided for bone matrix")
		self._matrix = matrix
	def getMatrix(self):
		return self._matrix


#main animation class
#bones must be a list of NoeBone objects, frameMats must be a flat list of NoeMat43 objects
class NoeAnim:
	def __init__(self, name, bones, numFrames, frameMats, frameRate = 20.0):
		noesis.validateListType(bones, NoeBone)
		noesis.validateListType(frameMats, NoeMat43)
		self.name = name
		self.bones = bones
		self.numFrames = numFrames
		self.frameMats = frameMats
		self.setFrameRate(frameRate)
	def __repr__(self):
		return "(NoeAnim:" + self.name + "," + repr(self.numFrames) + "," + repr(self.frameRate) + ")"

	def setFrameRate(self, frameRate):
		self.frameRate = frameRate


#procedural animation object - specifies some parameters which can be baked into an animation using createProceduralAnim
class NoeProceduralAnim:
	def __init__(self, boneName, angleAmount, axis, timeScale):
		self.setBoneName(boneName)
		self.setAngleAmount(angleAmount)
		self.setAxis(axis)
		self.setTimeScale(timeScale)
	def setBoneName(self, boneName): #string matching this procedural anim object to a bone
		self.boneName = boneName
	def setAngleAmount(self, angleAmount): #maximum sway degrees
		self.angleAmount = angleAmount
	def setAxis(self, axis): #axis of rotation (int, 0-2)
		self.axis = axis
	def setTimeScale(self, timeScale): #time multiplier for the duration of the animation
		self.timeScale = timeScale


#main mesh class
#all vertex types (positions, normals, uv's, etc) are expected to match in count, as they all share a single triangle list.
#it's recommended that you use the rapi.rpg interface if you want a convenient means to convert different data/primitive types into a NoeModel with NoeMeshes.
class NoeMesh:
	def __init__(self, triList, posList, name = "default", materialName = "default", glbVertIdx = -1, glbTriIdx = -1):
		self.setIndices(triList)
		self.setPositions(posList)
		self.setName(name)
		self.setMaterial(materialName)
		#glb's are indices into the parent model's globalVtx/globalIdx lists on export
		self.setPrimGlobals(glbVertIdx, glbTriIdx)
		self.setLightmap("")
		self.setTransformedVerts(None, None)
		#fill in placeholders
		self.setNormals([])
		self.setUVs([])
		self.setUVs([], 1)
		self.setTangents([])
		self.setTangents([], 1)
		self.setColors([])
		self.setWeights([])
		self.setMorphList([])
		self.texRefIndex = -1 #this is set by Noesis internally when you load a model's textures manually

	def __repr__(self):
		return "(NoeMesh:" + self.name + "," + self.matName + "," + repr(len(self.indices)) + "," + repr(len(self.positions)) + ")"

	def setName(self, name):
		self.name = name

	def setMaterial(self, materialName):
		self.matName = materialName

	#triangle lists are single-dimension lists of ints, expected to be divisible by 3
	def setIndices(self, triList):
		self.indices = triList

	def setPositions(self, posList):
		noesis.validateListType(posList, NoeVec3)
		self.positions = posList

	def setNormals(self, nrmList):
		noesis.validateListType(nrmList, NoeVec3)
		self.normals = nrmList

	#uv z component should typically be 0
	def setUVs(self, uvList, slot = 0):
		noesis.validateListType(uvList, NoeVec3)
		if slot == 0:
			self.uvs = uvList
		elif slot == 1:
			self.lmUVs = uvList
		else:
			noesis.doException("Unsupported uv slot")

	#translation component of NoeMat43 is ignored for tangents (matrix[0]=normal, matrix[1]=tangent, matrix[2]=bitangent)
	def setTangents(self, tanList, slot = 0):
		noesis.validateListType(tanList, NoeMat43)
		if slot == 0:
			self.tangents = tanList
		elif slot == 1:
			self.lmTangents = tanList
		else:
			noesis.doException("Unsupported tangent slot")

	#color lists are rgba values stored in vec4's
	def setColors(self, clrList):
		noesis.validateListType(clrList, NoeVec4)
		self.colors = clrList

	def setWeights(self, weightList):
		noesis.validateListType(weightList, NoeVertWeight)
		self.weights = weightList

	def setMorphList(self, morphList):
		noesis.validateListType(morphList, NoeMorphFrame)
		self.morphList = morphList

	#indices into the parent model's globalVtx/globalIdx lists on export
	def setPrimGlobals(self, glbVertIdx, glbTriIdx):
		self.glbVertIdx = glbVertIdx
		self.glbTriIdx = glbTriIdx

	def setLightmap(self, lmMatName):
		self.lmMatName = lmMatName

	#not currently used, planned in a future update
	def setTransformedVerts(self, positions, normals):
		self.transVerts = positions
		self.transNormals = normals

	#convenience function for checking if vertex components have valid content
	def componentEmpty(component):
		if component is None or len(component) <= 0:
			return 1
		return 0


#vertex weight. number of indices and weights should match.
class NoeVertWeight:
	def __init__(self, indices, weights):
		self.indices = indices
		self.weights = weights

	def numWeights(self):
		n = len(self.indices)
		if n != len(self.weights):
			noesis.doException("Weight without matching index/value length")
		return n


#vertex morph frame - represents a single frame of vertex morph animation
#note that it is valid for normals to be None (some models only want to provide positions for vertex anims), but positions should always be a valid list.
#a vertex morph frame should always have as many entries in its vertex lists as other vertex components in the mesh it belongs to.
class NoeMorphFrame:
	def __init__(self, positions, normals):
		noesis.validateListType(positions, NoeVec3)
		noesis.validateListType(normals, NoeVec3)
		self.positions = positions
		self.normals = normals


#global vertex which references per-mesh data
class NoeGlobalVert:
	def __init__(self, meshIndex, vertIndex):
		self.meshIndex = meshIndex
		self.vertIndex = vertIndex


#main model class
class NoeModel:
	def __init__(self, meshes = [], bones = [], anims = [], modelMats = None):
		self.setMeshes(meshes)
		self.setBones(bones)
		self.setAnims(anims)
		self.setModelMaterials(modelMats)
		self.setPrimGlobals(None, None)

	def setModelMaterials(self, modelMats):
		if modelMats is not None and not isinstance(modelMats, NoeModelMaterials):
			noesis.doException("Invalid type provided for model materials")
		self.modelMats = modelMats

	#animations will be applied to the model based on matching bone names from their local bone lists
	def setAnims(self, anims):
		noesis.validateListType(anims, NoeAnim)
		self.anims = anims

	def setMeshes(self, meshes):
		noesis.validateListType(meshes, NoeMesh)
		self.meshes = meshes

	def setBones(self, bones):
		noesis.validateListType(bones, NoeBone)
		self.bones = bones

	#note that globalVtx/Idx are ignored by Noesis (only mesh geometry is used), but are provided for convenience when exporting
	def setPrimGlobals(self, globalVtx, globalIdx):
		self.globalVtx = globalVtx #list of NoeGlobalVert
		self.globalIdx = globalIdx #triangle index (int) list referencing globalVtx


#random utility methods/classes

#convert a string to a padded bytearray
def noePadByteString(str, padLen):
	bstr = bytearray(str, "ASCII")
	if len(bstr) >= padLen: #check is >= under the expectation that the string should be 0-terminated
		noesis.doException("Provided string exceeds max length")
	exLen = padLen-len(bstr)
	bstr.extend(0 for i in range(0, exLen)) #pad out
	return bstr


#shortcut to get superclass
def noeSuper(clobj):
	return super(clobj.__class__, clobj)


#converts a list into bytes (providing items in list support toBytes)
def noeListBytes(lobj):
	b = bytes()
	for li in lobj:
		b += li.toBytes()
	return b


#converts a single-dimension tuple to a list
def noeTupleToList(tup):
	return [item for item in tup]


#converts bytes to string assuming standard ascii encoding
def noeStrFromBytes(bar, enc = "ASCII"):
	return str(bar, enc).rstrip("\0")


#construct a bytearray containing the contents of data up to the first 0
def noeParseToZero(data):
	dst = bytearray()
	for c in data:
		if c == 0:
			break
		dst += noePack("B", c)
	return dst


#can be referenced to bypass data format checks (not recommended if it's possible to identify a format by its raw content)
def noeCheckGeneric(data):
	return 1


#--------------------------------------------------------------------------------------------
#methods/classes beyond this point should not be referenced when the rapi-state is not valid.
#doing so will trigger a Python runtime exception.
#(rapi methods may create/reference per-instance pool allocation data, while noesis methods
#are guaranteed to work across instances)
#--------------------------------------------------------------------------------------------

#converts a list of NoeVertWeight objects into a flat list
class NoeFlatWeights:
	def __init__(self, vwList):
		self.numWeights = len(vwList)
		self.flatW = rapi.getFlatWeights(vwList, 0)
		self.weightValOfs = len(self.flatW) // 2
		self.weightsPerVert = (self.weightValOfs // 4) // self.numWeights
