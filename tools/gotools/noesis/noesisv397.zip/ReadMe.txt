This is Noesis version 3.97.

Noesis converts and previews many data formats. You can get an idea of which ones by looking at the file type mask droplist on the face of the application.

A NOTE ABOUT PLUGINS:
Noesis plugins run as native binary on your machine. This means that they can contain harmful and malicious code! Before you place any DLL file in your Noesis\Plugins folder, make sure you know who the author of the DLL is, and that you trust them completely!

In preview mode, the following controls are available:

1) Left Mouse: While held, moving the mouse will rotate your view around the focal point.

2) Left Mouse + CTRL: While held, moving the mouse up and down zooms your view in and out.

3) Right Mouse: While held, moving the mouse will move your focal point in the scene, relative to the direction you're looking. Your focal point is represented by a green/red box at the center of the screen.

4) Right Mouse + CTRL: While held, moving the mouse up and down moves your focal point "in" and "out" of the screen.

5) Middle Mouse: Clicking the middle mouse button re-centers your view on the model. Scrolling the mousewheel does what Left Mouse + CTRL does, with a larger step length.

6) The icons on the preview pane (and their corresponding F# keys) will change according to the data inside the file you are previewing. Remember to read the info text when the preview main is in focus for reference.

The red/green focal point in the center of the screen will only appear while you are holding down the right mouse button. If the box is green, it is not obstructed, but if it's red, that means it's "behind" the geometry you're looking at. This is helpful for determining the distance of your focal point when trying to center in on some geometry.

Additionally, many features and options are available through the Noesis menus. Explore and enjoy.

I'd also like to take this opportunity to remind some of you that you should NOT do any of the following things:

1) Distribute content ripped from a game/product without legal permission from the content owner(s).

2) Use Noesis as an integral part of a creative endeavor, then completely fail to mention Noesis in any associated documentation or credits.

3) Use Noesis to extract content, then make direct renders of it to post on your DeviantArt page, as if you somehow made the content yourself. 2 usually applies here, but this is also a violation of DeviantArt's terms of service in most applicable cases.

4) Use Noesis to rip and convert everything under the sun to a gmod ragdoll. (see 1)

5) Rip and sell, even in modified form, copyrighted content that belongs to someone or something else. This is one of the worst things you can do, and if you don't understand why it's disrespectful (and in most countries, illegal), you must have been raised in a den of murdering whores.

6) Generally fail to adhere to certain standards of creative decency and respectful attribution. (see 1-5)

If you're guilty of any of these things, knock it off.

===============
What's New
===============
Version 3.8-3.97:
 -3.97 - Added rapi.toolLoadGData, rapi.toolFreeGData, rapi.toolSetGData, rapi.toolExportGData, rapi.toolGetLoadedModelCount, and rapi.toolGetLoadedModel. These functions are intended for tool scripts, and allow loading/saving/manipulating any kind of supported (models, textures, etc.) data.
 -3.97 - Added noesis.instantiateModule, noesis.freeModule, and noesis.setModuleRAPI. These functions allow you to insantiate modules and set the active rapi module context, and are intended for use with tool scripts.
 -3.97 - Added noesis.getSelectedFile to get the path of the currently selected file in the Noesis browser.
 -3.97 - Added noesis.loadImageRGBA and noesis.saveImageRGBA. These are mainly for convenience, as the same functionality can be achieved with the new module instantiation and tool methods.
 -3.97 - Added a "Use memory mapping" persistent setting. This may result in a barely-detectable performance penalty in some situations, but will utilize 64-bit address space for some of the Noesis interfaces in order to circumvent some 32-bit memory limits.
 -3.96 - Added HL1 MDL import support.
 -3.96 - Added a "Snapshot" button to the Kinect dialog.
 -3.96 - Fixed multiple memory leaks in JK support.
 -3.96 - Fixed a possible crash when reporting memory leaks.
 -3.96 - Improved memory management for MD3 export, also capping import frame count when necessary.
 -3.96 - Added NOEUSERVAL_SAVEFILEPATH to compliment NOEUSERVAL_FILEPATH.
 -3.95 - Added support for bone-only NMD files.
 -3.95 - Fixed a potential crash on export with no geometry.
 -3.95 - Added Castlevania Dracula X Chronicles .res extraction support.
 -3.95 - GMO's which do not contain internal textures now use the correct external material reference names.
 -3.94 - Added a fullscreen preview option. (View->Fullscreen in the menu)
 -3.94 - Added extraction support for Jedi Knight/Mysteries of the Sith GOB/GOO files.
 -3.94 - Added import support for JK/MotS MAT textures.
 -3.94 - Added import support for JK/MotS 3DO models.
 -3.94 - Added import support for JK/MotS KEY animations.
 -3.94 - Added import support for JK/MotS JKL models.
 -3.93 - Added NPAPI_UserSettingWrite/NPAPI_UserSettingRead, which allows native plugins to write/read settings in the Noesis registry section.
 -3.93 - Added NPAPI_Threads_DoJob and NPAPI_Threads_JobDone, so that plugins can offload tasks to the multi-threaded Noesis job system.
 -3.92 - Extended "mergeBones" option again. If it is set to 3, functionality for 2 performed, and geometry is also transformed with new bone matrices.
 -3.92 - Added a "renameBone" option for the .noesis scene files.
 -3.92 - Fixed a possible memory leak caused by the merging of textures between 2 different models.
 -3.91 - Extended "mergeBones" option. If it is set to 2, relative bone transforms are re-applied after the bone collapse.
 -3.9 - Added "mergeTo" and "mergeBones" options for .noesis scene files, which allow models (and their skeletons/animations/materials) to be merged into a single model.
 -3.9 - Exposed new noesis.getScenesPath method.
 -3.9 - Exposed new noesis.openFile method.
 -3.89 - Added a generic input prompt method, noesis.userPrompt.
 -3.89 - Added a new method for scripts to regiser tools, noesis.registerTool. New tools will be listed under the Noesis "Tools" menu once they're registered.
 -3.89 - Added anaglyphic stereoscopic rendering, which can be enabled through the data viewer. (Persistent settings->View->Anaglyph 3D) Anaglyphic rendering obeys all of the same stereo settings as quadbuffered stereo rendering. (quadbuffering is only functional, to my knowledge, on nVidia Quadro cards)
 -3.89 - Fixed matrix translation being uninitialized memory when converting a quaternion to a 4x3 matrix in Python.
 -3.89 - User preference version value has been changed, so your preferences will be reset when you run this version.
 -3.89 - Other assorted fixes and additions that I've lost track of.
 -3.881 - Now grabbing proper texture names from PVM files.
 -3.88 - Updated OpenNI implementation to 1.5.
 -3.88 - Added an "Append" record option in the Kinect interface. This will append new frames to the end of the existing framelist, instead of overwriting.
 -3.88 - Added Dreamcast PVM file support.
 -3.872 - Optimized the rpg vertex structure to lower memory usage very significantly.
 -3.871 - Defaulting to flat shading for STL import.
 -3.87 - Added import+export support for Standard Tessellation Language (STL) models.
 -3.87 - Added prevention for recursive exceptions in the exception handler, in the event that things are somehow so broken that the exception handler itself crashes. (and/or a crash occurs in the messagepump for the report dialog)
 -3.866 - Passing a negative bit value into the PVRTC decoder will force bilinear lookups. The results can be visually inferior, but are more authentic. (in line with official PVR hardware and viewers)
 -3.866 - Added CRC validation to the auto-updater.
 -3.866 - Corrected a bug that was causing non-default blend modes on lightmap materials to not be obeyed.
 -3.866 - Made the outpath path for the batch exporter scriptable. Do not abuse this.
 -3.866 - Random bug/crash fixes.
 -3.865 - Yet more timing/messagepump bug fixes. (I just had the chance to try Noesis on a horribly underpowered machine, it's flushing this stuff out of the woodwork)
 -3.864 - When message throttling is enabled, paints are also aborted if other messages are in the queue. This prevents Noesis from flooding the queue on systems with incredibly bad rendering performance.
 -3.864 - Exposed interval of regular update timer in the system settings. (mostly for diagnostic use)
 -3.863 - Fixed a rather nasty bug in the data viewer that could result in a crash when texture/animation counts happened to be just right.
 -3.862 - Exposed noesis.morton2D in Python.
 -3.861 - Small fix for Python immediate-mode drawing.
 -3.86 - Added -imgbicubic, to force bicubic sampling. (instead of bilinear)
 -3.86 - Added -imgcrop.
 -3.86 - All image operations are now correctly stacked and performed in the order that the arguments are provided.
 -3.86 - Added noesis.NTEXFLAG_FILTER_NEAREST and noesis.NTEXFLAG_WRAP_CLAMP so that scripts can provide texture mode hints.
 -3.86 - If a texture is being previewed and using nearest filtering, it will be snapped to the nearest fixed point offset, as well as round to the nearest fixed point zoom level with a 0.1 threshold. (in order to allow easier examination of uniform pixels)
 -3.86 - Fixed a crash when passing NULL vertex components in with immediate-mode rendering. (this is valid behavior for removing active components)
 -3.86 - Moved COLLADA from the Noesis core into an external plugin module. I fixed some material/texture issues with it while I was at it.
 -3.858 - Added support for 1bpp, 4bpp, and 16bpp BMP files, as well as RLE compression modes.
 -3.857 - Exposed external texture material name strings in the data viewer.
 -3.857 - Added support for 8bpp BMP files. (note: BMP support is still half-assed)
 -3.856 - Added ability to reset XMem LZX streams every n frames (in addition to specifying the use of frame reset/size data) by providing negative frame intervals.
 -3.856 - Fixed some output naming/extension bugs.
 -3.856 - Fixed subsequent images not being written out in the selected image format for data sourced from an image (as opposed to model) import.
 -3.855 - More various bug/crash fixes, and corrected a bug that could cause Model_LoadNoesisTexturesForModel to incorrectly grab duplicate textures.
 -3.854 - Various bug/crash fixes.
 -3.853 - Added support for extracting Desert Strike archives, and import support for its picture/sprite graphics.
 -3.852 - Added a high-precision PVRTC decoder function to native and Python API's. Also included a simple script to parse PVRTC-compressed .pvr files in V2 and V3 form.
 -3.852 - Fixed a bug in the "load TIM2" plugin extension which was causing returned texture data to always be untwiddled.
 -3.851 - Quick fix to make UV viewer work on meshes without textures. (a red default background is used)
 -3.85 - Added a "UV flip" property for meshes in the data viewer, as well as a "Global UV flip" under the model. If the global UV flip is set, it will override any per-mesh preferences.
 -3.849 - More GMO fixes. Discovered a couple of places where the GMO loader was crapping all over the stack. Fixed those instances and moved some arrays to the heap with write boundaries. Be on the lookout for new crashes! (and submit them if they come up)
 -3.849 - Exposed a "Culling flag" property for meshes in the data viewer. 0 = default culling mode, 1 = no culling, 2 = reverse culling.
 -3.848 - Added a bunch of new immediate-mode drawing functions to the Python interface.
 -3.848 - Added recognition of reset state command to LZX decompressor.
 -3.848 - Fixed another GIF import bug where row offset wasn't being correctly applied for non-interlaced images.
 -3.848 - Fixed a crash in the GMO loader, and fixed several triangle indexing bugs.
 -3.848 - Added rapi.loadMdlTextures to the Python API, see __NPReadMe.txt for usage.
 -3.847 - I really need to stop jumping the gun on new releases. More GIF fixes, cumulative transparency is now handled correctly, and the GCE flush flag is now obeyed. Also exposed additional texture info in the data viewer.
 -3.845 - Added automatic texture animation to preview mode. When a file is loaded which has an array of textures but no model, the textures will automatically begin cycling. You can also pause the cycling and jump back and forth with the arrow buttons.
 -3.845 - Made image framerate preserve for GIF export if it exists. This also preserves framerate across GIF-GIF conversions. If -gifdelay is used, that value still overrides existing per-frame timings.
 -3.844 - Added -gifnoalpha, which eliminates alpha masking on GIF import and allows Noesis to preserve cumulative screenbuffer effects.
 -3.842 - Small adjustment to color reduction for GIF files.
 -3.841 - Quick fix to pluginshare.h.
 -3.84 - Added Decomp_XMemLZX (native API) and decompXMemLZX (Python API) for decompressing XMemCompress (or other MS LZX) streams.
 -3.84 - Added import support for Grandia 2 models. Thanks to Mat for his work in figuring out the compression used in this game.
 -3.84 - Added import support for Love Hina: Smile Again models.
 -3.84 - Added import/export support for GIF images. For animated images, additional frames can be viewed under "Textures" in the data viewer. When exporting to the GIF format, a batch writer is used which grabs all textures/images being exported and writes them to a single animated GIF file.
 -3.84 - Added a maximum length for the export log buffer, can be changed under System in the data viewer.
 -3.84 - Enabled support for extracting MVC3 360 .arc files.
 -3.84 - Improved color precision and contrast of the median cut algorithm.
 -3.84 - Added NPAPI_SetTypeHandler_WriteRGBABatch for image formats that want to export from all texture sources in a given export process.
 -3.84 - Added Image_GetTexRGBA to get raw RGBA32 data from a Noesis texture regardless of its internal format.
 -3.84 - Fixed a crash where Noesis could mistake unrelated data for being a Quake BSP file.
 -3.84 - Fixed a potential crash in validation of .ico files.
 -3.84 - Fixed a bug where outputting to a batched image format (like .spr) was not working in conjunction with model export.
 -3.84 - Fixed a potential conflict when exporting to a format with the same file extension as another different format.
 -3.832 - Quick fix for Python bitstream class.
 -3.831 - Added crude support for NS:UNS2 models. No skeleton (seems to be in a different file), material assignments are usually off, some meshes are offset, and some meshes just have screwed up verts. Seems like a vertex format or offset issue, haven't looked into it.
 -3.83 - Added a viewing mode for UV coordinates. (select "UV view"/"LMUV view" under the desired mesh in the data viewer)
 -3.83 - NMD files from SC5 are now loadable.
 -3.83 - Fixed a bug preventing materials from being assigned for Python export scripts.
 -3.83 - Fixed a bug where Noesis could overflow its message pump by spamming too many paint messages, causing the program to sometimes become unresponsive. The new behavior can still be reverted by enabling the "Disable message throttle" System setting, but this is not recommended.
 -3.83 - Fixed a COLLADA import crash, when a controller node instance does not reference a valid entity.
 -3.83 - Fixed an OBJ import crash when the file has out-of-range indices.
 -3.83 - Fixed a crash when attempting to load TEX files with bad mip offsets.
 -3.83 - A couple of fixes to the device image creator. It will now skip over unreadable sectors and fill them out in the image file instead of aborting when it hits them.
 -3.82 - Quick fix for XPR files being incorrectly recognized as NG2/DOAX2 models.
 -3.81 - Fixed a potential FBX crash, where the FBX gives control point indices that are out of range.
 -3.81 - Fixed several potential crashes in the md5mesh loader.
 -Fixed a potential crash when extracting FFX disc images.
 -Fixed a potential crash when loading unsupported Source MDL files.
 -Various other small additions and fixes.

Version 3.7-3.79:
 -Now applying an unroll filter before exporting FBX animation rotation curves, which typically fixes bad linear interpolations when playing animations back from other FBX viewers/importers. Special thanks to Viviane Rochon for informing me of this solution.
 -Lots of under-the-hood changes. Things may explode. I'm interested in crash reports, so send them in, and try to make them useful. (e.g. provide sample files, and ideally provide process module base addresses with instruction pointer offsets for each thread)
 -3.71 - Upped the bone name limit in the Python plugin to reflect the new limit in the bone structure.
 -3.71 - Made UMvC3 models load.
 -3.72 - Added Zegapain XOR support to Bullet Witch Python script.
 -3.72 - Optimized vertex structure and memory use for the procedural geometry interface, and removed the 16 weights per vertex limit.
 -3.72 - Added decompLZHMelt/Decomp_LZHMelt to the Python/C++ API's.
 -3.73 - Added rpgSetStripEnder/rpgGetStripEnder to specify (or get) the value which ends/resets triangle strips mid-buffer. For most console games this should be set to 0xFFFF, but it can differ per title.
 -3.73 - rapi.createProceduralAnim is now available in Python, with a new NoeProceduralAnim object for specifying procedural animation parts. See the commented out example in the Bullet Witch script.
 -3.73 - Added a readline method to the NoeBitStream at the request of chrrox.
 -3.73 - Exposed and tested loadTexByHandler in Python. Example use:
	def proxyLoadRGBA(data, texList):
		f = open("c:\\other\\somefile.jpg", "rb")
		tex = rapi.loadTexByHandler(f.read(), ".jpg")
		f.close()
		if tex is not None:
			texList.append(tex)
			return 1
		return 0
 -3.73 - Now resetting the bit pointer in the stream container when doing a byte-level seek.
 -3.73 - Updated BVH plugin to use the new bone name string limit.
 -3.73 - Fixed a bug causing validateListType to sometimes raise its exception in the wrong place.
 -3.73 - Added support for ATI1 (BC4) DXT compression. ATI2/BC5 has already been supported for a while.
 -3.73 - Added support for Dead Rising 1 360 .tex files.
 -3.73 - Fixed MVC3 360 spec maps not being handled correctly.
 -3.73 - Added support for 360 DMC4/RE5/LP .tex files. PS3 files are not supported.
 -3.73 - Added support for 360 DMC/RE5 .mod files. PS3 files are untested and probably don't work.
 -3.73 - Added support for 360 LP/DR1 .mod files. Not well-tested, but works on the files I've tried.
 -3.73 - Fixed certain material properties not being obeyed in the preview render with externally-loaded textures.
 -3.73 - Fixed a potential crash when loading external textures without extensions on a wide-character path.
 -3.74 - Special thanks again to LUBDAR for another donation!
 -3.74 - Added FFXIII-2 support.
 -3.74 - Made normal/spec/etc. texture index properties in data viewer modifiable.
 -3.74 - Now looking for XDVDFS markers at 0x2080000 as well for ISO extraction. (this handles FFXIII-2 for 360)
 -3.741 - Quick bugfix for FFXIII-2.
 -3.742 - Another quick fix for loading PS3 FFXIII-2 models. If the image bundle extension is .ps3.imgb (which means the model's extension must be .ps3.trb), then the texture data will not be untiled.
 -3.75 - Another thanks to dear old brother Bradford for an uneven-penny'd donation, and a congratulations for another set of academic milestones met. :)
 -3.75 - Added a custom exception handler which can send off crash logs to my web site. Please say yes when it asks you if you want to send the log.
 -3.75 - Noesis is now capable of auto-updating itself. There is an option to check for updates in the Tools menu, as well as a persistent option (accessible from the data viewer) to tell it to automatically check for updates on startup.
 -3.75 - Added support for .RZL+.RZP archives, used in Lord of Apocalypse and possibly other games.
 -3.75 - Removed link dependency on psapi.dll.
 -3.751 - Made the debug log window resizable.
 -3.752 - Changed default HTTP transfer timeout.
 -3.76 - Kinect support (with OpenNI/NITE) is working again.
 -3.77 - Removed all OpenGL dependencies and integrated a new graphics API standard into all of the Noesis modules. A new graphics module that uses OpenGL is now provided. (Direct3D and/or software renderers will probably be coming in the future)
 -3.77 - Fixed another bug in the Kinect module.
 -3.77 - Added RPGEO_QUAD_ABC_BCD, RPGEO_QUAD_ABC_ACD, RPGEO_QUAD_ABC_DCA to cover other common quad index order conventions. (RPGEO_QUAD is ABC_DCB, as now denoted by the comment in pluginshare.h)
 -3.77 - Fixed a crash in the SMD loader.
 -3.77 - When you select a bone in the data viewer, shift+clicking will auto-enable the bone's transform offset and allow you to rotate the bone with your mouse. (left and right buttons control which axes you're rotating)
 -3.77 - Fixed a bug that occurred when parsing OBJ files with blank usemtl entries.
 -3.771 - Fixed another crash in the SMD loader, and a bug in the SMD exporter with textures that have spaces in their names.
 -3.772 - Various fixes for the new rendering system.
 -3.774 - Dependency fix for the ODE physics module.
 -3.775 - Fixed a "reload plugins" crash that was introduced by the new renderer changes.
 -3.78 - Copied animations will now be exported with secondary models as well as the primary. (GMO files with multiple models and animations shared between models were only getting animations exported with the first model in the file)
 -3.78 - Added "sharedAnims" option for .noesis files.
 -3.79 - Fixed a crash when loading COLLADA files and encountering NULL child node or scene root pointers.
 -3.79 - Fixed a crash when trying to generate vertex normals for a mesh with no vertices or out-of-range triangle indices.
 -3.79 - Added more post-load sanity/safety-checking logic for triangle/weight/etc. values.
 -3.79 - Weapon models for Zell and Kiros are now loadable with the FF8 module. The skeleton is stored externally for those weapons, so you'll be required to select a Zell/Kiros character model when you load the weapon model in order to import the skeleton.
 -3.79 - Fixed a bug introduced by the recent renderer changes that was causing Noesis to upload resize some non-power-of-2 textures even on hardware with NPoT texture support.
 -3.79 - Noesis will now obey the reported maximum texture size from hardware and resize textures appropriately before uploading.
 -3.79 - Fixed a possible crash when loading non-power-of-2 DXT data on hardware without NPoT texture support.

Version 3.6-3.69:
 -Added support for DOTA2 (and maybe others) Source MDL files. Special thanks to Quest and chrrox for providing test files.
 -Fixed a possible reference count error when exporting animations from Python.
 -Changed geometry lists provided by the Python implementation to default to tuples instead of lists, since they usually aren't modified after being handed back.
 -Added .mtl import/export. To export .mtl with .obj, -objmtl must be used.
 -3.61 - This build is hereby dedicated to Bradford, for sending me another 10 dollars via PayPal to spend on booze.
 -3.61 - Added import/export of FBX files. Don't bug me about issues related to scaling, rotation/orientation, UV flipping, or vertex normals. Max tends to screw normals up when importing with skin modifiers. (if you want normals intact you can uncheck deformers in the FBX import options) Seems like a bug in the FBX SDK and/or Max importer.
 -3.61 - Fixed handling of weights for Source MDL dx90 vertices.
 -3.61 - Improved validation of FF Type-0 models to eliminate false positives. (only tested on Japanese demo)
 -3.62 - Thanks to firsak for another PayPal donation! I think I've spent enough on booze though. I guess I'll order a pizza.
 -3.62 - Fixed filetype filter being case-sensitive for formats with capital letters in their extensions. Thanks to revelation for discovering this one.
 -3.63 - Fix for crash on load of some FF Type-0 models.
 -3.64 - Fixed a bug where the checked file extension was not correctly reset at times. (as far as I know, this only caused bugs with identifying file types in the status bar)
 -3.65 - Added a scene scale setting, in the data viewer under persistent settings. Acts as a multiplier for the preview scene scale. (which mainly affects movement speed and clipping planes)
 -3.65 - Added a "recenter on meshes" option in the data viewer under persistent settings. When enabled, this will cause the preview view to recenter on meshes when you select them in the data viewer. Useful for extremely complex scenes.
 -3.65 - Added more under the hood error-checking for incoming bone and animation data.
 -3.65 - Fixed an issue with FBX import where initial mesh matrix was not accounted for on skinned meshes.
 -3.66 - Now handling multiple animation stacks in FBX scenes.
 -3.66 - New double-precision modes and functions in the API.
 -3.66 - Switched FBX plugin over to double-precision for everything, and added re-normalization of weights if any error is present at all instead of an error of more than 0.0001. (I ran into some extremely large scenes where weighting precision was causing vertices to drift over long distances)
 -3.67 - Fixed a possible crash with bone name length in the IQM plugin.
 -3.67 - Fixed a bug which was preventing Noesis from sleeping between frames, and exposed standard and background frame intervals in the persistent settings in the data viewer.
 -3.67 - Added -fbxscalehack for the FBX plugin. The current FBX SDK is failing to correctly incorporate scale into local and global transforms, this is a hack workaround for that.
 -3.68 - Fixed a possible crash in skin handling for Quake MDL files.
 -3.69 - Added automatic filtering of output image names, added Noesis_FilterFileName and Noesis_FilterFileNameW to the API so that plugins can use the same filename filtering methods that Noesis uses internally.
 -3.69 - Enforced correct struct alignment for structures in pluginshare.h.

Version 3.5-3.59:
 -Added the ability to feed tangent vectors into the RPG interface.
 -Optimized allocation scheme for the generic "get unique elements" function exposed in the C/C++ plugin API.
 -Added rpgSetOption/rpgGetOption. rpgSetOption has eliminated the need for rpgSetEndian and rpgSetTriWinding.
 -Various other mostly-behind-the-scenes fixes and optimizations.
 -3.51 - Added rapi.imageDecodeRawPal.
 -3.52 - Added Quake II .wal import+export support via Python script.
 -3.52 - Added Quake II .bsp import support via Python script.
 -3.52 - Added Noesis_LoadExternalTex/rapi.loadExternalTex.
 -3.52 - Added rpgSetLightmap, allows lightmap and/or second-pass rendering to take place with named material references.
 -3.53 - Changed Quake II lightmap packing. (traded off better packing for better load time and batching)
 -3.53 - Added lightmap material property to meshes in the data viewer.
 -3.54 - Added rapi.getInflatedSize for chrrox.
 -3.55 - Added rapi.loadTexByHandle, various other changes/fixes.
 -3.56 - Unified the animation preview functionality between models with anims and anims without models.
 -3.56 - Added mouseover status bar help tips for the model control buttons. (suggested by Tomaz)
 -3.56 - Added import and export support for BVH animations.
 -3.56 - Various additions/changes in plugin API land.
 -3.57 - Added software-resizing of image data before uploading non-power-of-2 textures on hardware where they aren't supported.
 -3.58 - Added base orientation change option to anim-only preview mode.
 -3.58 - Added an optional new flags parameter to imageDecodeRaw/imageDecodeRawPal in the Python API. See the DECODEFLAG_* values listed in __NPReadMe.txt.
 -3.58 - Added imageScaleRGBA32 to the Python API.
 -3.59 - Compiled CRT into Python library to circumvent a stupid Wine problem, and added/fixed a few other things.

Version 3.4-3.49:
 -Rebuilt plugins to force dependencies on older versions of the MSVC runtimes.
 -Added a "Making Plugins" section to the ReadMe.txt.
 -3.41 - Added stereoscopic rendering. Only works on hardware capable of creating a windowed stereo context. (like Quadro cards)
 -3.41 - Added a stereo option to the ultra-shot, to generate stereo renderings. This doesn't require stereo-capable hardware.
 -3.41 - Stereo rendering parameters (and other stuff, which will likely continue growing) can now be set in the "Persistent parameters" section of the data viewer. Some changes (such as enabling stereo) may require Noesis to be restarted to take effect.
 -3.42 - Fixed GL context going bad after using the "Reset all" option.
 -3.43 - Added NTEXFLAG_STEREO flag for textures.
 -3.43 - Added import+export support for JPS (stereo image) format.
 -3.43 - Added import+export support for MPO (stereo image) format. Now you can directly convert and transfer Noesis stereo renders for 3D viewing on your Nintendo 3DS.
 -3.43 - When previewing stereo images in active stereo mode, Noesis will now recognize this and display the correct image for each eye.
 -3.43 - Added a stereo texture offset option for stereo image display.
 -3.43 - Added a stereo eye swap option.
 -3.44 - Added -mpo3ds option, to force Nintendo 3DS header on MPO export. (allows you to use the offset slider when viewing the file on a 3DS - seems to only work on 640x480 images)
 -3.45 - Added -imgresz option, resizes all images to the specified dimensions.
 -3.45 - Added -imgmcut option, performs a median cut on all images.
 -3.46 - Added a new Python plugin. You can now write Python scripts to add support for new formats and other things. Special thanks to chrrox for helping test and provide feedback on Python stuff pre-release. Check out the plugins\python directory, or specifically plugins\python\__NPReadMe.txt for info on the Python implementation.
 -3.46 - Corrected the export dialog treating some image formats as non-image formats.
 -3.46 - Changed Quake PAK handler from memory streaming to disk streaming.
 -3.46 - Added support for extracting Duke3D .grp archives and viewing Duke3D .art tiles. (via Python script)
 -3.46 - Added import and export support for .m32 (Soldier of Fortune, possibly others) textures. (via Python script)
 -3.46 - Corrected a typo in one of the RichMat44 constructors.
 -3.46 - Added FF Type-0 model import. (note - the PKG extractor will try to detect .t0mdl files now and write them to a t0mdl folder, but it does get some false positives, so not all those t0mdl files are really models)
 -3.46 - Added Bullet Witch CPR model/texture import support, via Python script.
 -3.47 - Added Ofs variants for all of the rpgBind*/rpgFeed* Python functions, and changed the Bullet Witch script to use them.
 -3.47 - Added rpgConstructModelSlim, which omits various data types you probably won't need. (cuts BW load times in Python down by about 50%)
 -3.47 - Fixed some Bullet Witch models not getting their material names parsed.
 -3.48 - Small fix to array endian swap routine.
 -3.49 - Python math types can now operate with both tuples and lists. Changed the default type to tuple. (if you attempt to modify a tuple-based type, it will have to convert its internal storage to a list)

Version 3.3-3.39:
 -More DNF material additions/fixes, now correctly parsing most of the possible material parameters.
 -Added extraction of StaticMeshes for DNF.
 -Static DNF meshes can now be previewed/exported, but do not have material mappings. (due to the dependency order, this would have been a big pain in the ass)
 -3.31 - Added -mdlnobase option.
 -3.31 - Fixed a possible crash when resizing texture page for MDL output.
 -3.31 - Added Quake .spr import+export.
 -3.31 - Added .tspr import+export.
 -3.31 - Added Quake .lmp import+export.
 -3.31 - Fixed an alpha bug that occurred exporting RGB image data to RGBA PNG files.
 -3.32 - Updated the IQM plugin at the request of Randy. It now handles importing v1 and v2 files, and exports v2 instead of v1.
 -3.33 - Added new -vertbones option which creates a bone for each vertex. If the model has vertex anims, "skeletal" anims are generated for the per-vertex bones.
 -3.34 - Fixed crash in SMD importer with long bone names.
 -3.35 - Fixed BMP import/export not padding to 32-bit boundary for scanlines.
 -3.36 - Added support for extracting Record of Lodoss War (Dreamcast) data files, and exporting its model and texture files.
 -3.36 - Fixed a preview rendering bug with certain kinds of non-triangle geometry.
 -3.37 - Made PSK drop trailing spaces on bone names by default. Behavior can be changed back with -pskkeepspace.
 -3.38 - Various behind-the-scenes fixes and cleanup.
 -3.39 - Added Tales of VS .mgz support.
 -3.39 - Fixed possible GMO crash on line primitives.

Version 3.2-3.29:
 -Added MVC3 360 model/texture support. 360 .tex files must have a .360.tex extension to be handled correctly. Textures are not mapped properly, but materials are. Thanks to aluigi and chrrox for the 360 arc bms script.
 -Finally made DXT export handle non-power-of-2 images.
 -Other random changes/fixes.
 -3.21 - Fixed a bug that was causing .360.tex files to not be recognized as 360 .tex files.
 -3.22 - Added MDR import+export support.
 -3.22 - Re-sorted command line option print-out.
 -3.22 - Added NPAPI_AddTypeOption for plugin authors. This allows plugins to add new advanced/command-line options, and provide callbacks for those options.
 -3.22 - Properly preserving mesh names across various formats that weren't before, added mesh name redundancy checking.
 -3.22 - Fixed a bug with rotating/translating/scaling bones while exporting from files with multiple models.
 -3.23 - Added EF engine limit warnings to MDR plugin.
 -3.24 - Fixed a crash introduced by 3.22 for certain models with duplicate mesh names. (thanks to firsak for catching the crash)
 -3.25 - Made vertex culling routine a lot faster.
 -3.25 - Made IQM importer read mesh names.
 -3.25 - Fixed MDR crash when exporting without anims.
 -3.25 - Internal matrix->quaternion routine now does a better job at handling skewed matrix input.
 -3.25 - Redid mesh decimation functionality and changed command-line syntax.
 -3.26 - New DNF plugin, handles extracting 5 varieties of .dat files from the DNF demo.
 -3.26 - Small changes/fixes to the plugin API.
 -3.27 - Added DNF demo .msh support. Attempts to auto-load .skl and .def, as well as necessary resources from MegaPackage.dat and the texture directory. Most of the time attempts to auto-grab materials+textures will fail, however, as I still don't have the dmx/dtx files figured out well enough.
 -3.28 - Fixed DNF normal texture package handling - now handles bundled entries (e.g. normal+spec in a single file entry) and gets all the names right.
 -3.28 - Various new plugin API functions/features - check pluginshared.h.
 -3.29 - More DNF-related fixes/changes.

Version 3.1-3.19:
 -Added FF9 plugin. Supports extracting FF9.IMG and "ff9db" packages, as well as viewing resulting .ff9mdl and .ff9anm files. Only models/anims from dir07 (monsters) and dir10 (playable characters) are fully supported, though. Thanks to Satoh for sending along a lot of FF9 info, as well as Zidane2, Zande, Chev, and possibly others. (the docs I have don't contain any attributions)
 -Added "Image_LoadTIM1" extension for plugin authors.
 -Added a set of streaming file interface functions to the plugin API.
 -3.11 - Bone length fix for FF9.
 -3.12 - Made GMO anims load with no bone mappings, if there is only 1 bone and 1 anim track.
 -3.13 - Fixed some more GMO animation and bone scaling issues.
 -3.14 - Added Shadow Hearts .pack plugin, which reads the .pack files from chrrox's BMS script. Both models and anims are supported.
 -3.15 - Display UV coordinates for verts (when enabled) in data viewer.
 -3.15 - Added FX Fighter plugin, supports .dat models and autoloads .ani animations for character models.
 -3.15 - Added rpgSmoothNormals for plugin developers.
 -3.15 - Fixed a texture name export bug when using -texpre.
 -3.16 - Various things. Oh, and fixed a GMO negative scale bug.
 -3.17 - New console/command line mode, activated by ?cmode as the first command-line argument. Check the "Command Line Mode" section of this document for more info.
 -3.17 - A new Image_GetMedianCut function based on the work of Anton Kruger. Also made the .m8 exporter use this for better results from high-color images.
 -3.17 - More things that I haven't kept track of.
 -3.171 - Small addition to ?cmode functionality.
 -3.18 - Windows icon file import/export support. (I got sick of somehow never having a good icon exporter on hand) Doesn't do Vista/7-style PNG icons though, didn't have any on hand to test.
 -3.18 - More random fixes and crap.
 -3.19 - Replaced -loadrda with -loadanim, and made it work with any supported animation format. (including formats that are models+anims) -loadanim may also be specified more than once for anim concatenation.

Version 3.0:
 -Added support for Saint Seiya: The Hades GMI+TPL files. Plugin source is included. Thanks to fatduck for the file layout, and qslash for additional contributions.
 -Added support for DQ&FF in Itadaki Street Special JOB files. This is through the Saint Seiya plugin as the formats are very similar.
 -Added "Image_LoadTIM2" extension for plugin authors. See the ssthehades_gmi plugin for example usage.
 -Added a new option for SetPreviewOption - "noTextureLoad". Allows a plugin to disable auto-loading additional textures based on filenames for preview mode.
 -Added Noesis_AnimFromAnims and Noesis_AnimFromAnimsList functions for plugin authors. Combines multiple animations and sequences into a single animation with a sequence list.

Version 2.99:
 -Started writing a CPU emulator for the R5900. It can be invoked within Noesis to run native PS2 game code for specific tasks. The R5900 core will be exposed to plugin developers when it is more complete.
 -Added support for unpacking Bujingai's compressed .bin files. (the main AFS containers have already been supported by Noesis for a long time) This uses the R5900 core to decompress data, and find package index tables inside the game's ELF. I used symbol offsets in determining my points of code execution, so hopefully this will also work on different distributions of the game, but I make no guarantees.
 -Added import support for Bujingai models and textures. Praise be to Gackt! Materials will probably be messed up for most models, though, and level bits don't get snapped into place. And some stuff may just not work at all. Who knows. Animations are also loaded, but arm/leg bones are usually screwed up, because I'm not handling IK joints correctly.
 -Fixed COLLADA exporter bug where models that use multiple materials under the same name would only export a single material.
 -Fixed COLLADA vertex alphas not being imported.
 -Fixed problems with exporting to COLLADA with non-normalized vertex weights.
 -Added "No browse to target" option under the view menu. This prevents Noesis from browsing to the path of the loaded file in the shell folder view, as well as from browsing to the last selected folder on startup.
 -Added "Don't apply on drag" option under the view menu. This removes the prompt asking if you'd like to apply the model to the existing scene (if a scene is already open), and defaults to always loading the drag-and-dropped item as a new scene.
 -Now printing vertex indices next to individual triangles in data viewer.
 -Now printing bone indices, if applicable, next to individual vertices in data viewer.
 -Exposed Noesis_UntwiddlePS2 for plugin authors.

Version 2.9-2.982:
 -Added support for importing FFX models and animations. These would not be here without revelation, who provided a full spec for each. Thanks revelation!
 -Added support for FFX disc image extraction. Handles decompression and sorting files into folders. Thanks to revelation once again for the filesystem info!
 -Added support for The Bouncer's .tex, .fe. and .sk files. Thanks to shadowmoy for basic info on sk geometry!
 -Added support for The Bouncer's bouncer.bin, extracts .bin files recursively.
 -Added a "Create device image" option to the tools menu. Uses wnaspi32.dll to create a raw sector rip of the selected device. Will also continue reading beyond the device's reported size, if possible.
 -Added model/texture import support for TC:RS .ndp3 files. (skeleton+models+textures supported, but still a WIP)
 -Added extraction support for TC:RS .pac files.
 -Added T3B .pack model/texture import support. (note: not all .pack files contain model or texture data, and so some .pack files will not be recognized)
 -CommitTriangles can now be called with NULL data, which will automatically build an ordered list up to the number of indices given.
 -Made CPK extractor handle encrypted UTF data seen in Hyperdimensional Neptunia. Thanks to tpu for posting the decryption routine.
 -Added noesisExtTexRef_t with Noesis_AllocTexRefs for plugin developers. External texture reference objects can be attached to materials.
 -Added NMATFLAG_TWOSIDED and RPGEO_TRIANGLE_STRIP_FLIPPED for plugin developers.
 -Various new primitive types for plugin developers. Some of them aren't correctly implemented, though. If you use one and it doesn't work, let me know and I'll fix it for you.
 -This release marks over 100 unique file formats supported by Noesis. Truly, I have too much time on my hands.
 -2.92 - Still fixing various post-2.9 bugs.
 -2.95 - New functionality for materials in pluginshare.h.
 -2.95 - Made Noesis_AllocTexRefs automagically handle the "-texpre" option.
 -2.95 - Made COLLADA and obj exporters properly differentiate between material and external texture reference names.
 -2.95 - Fixed up unicode support a bit, allowing models on unicode paths to be previewed.
 -2.95 - Made some non-s3tc DDS files load. Thanks to Mirrorman95 for example files.
 -2.95 - Fixed relative-indexing in the obj loader. Thanks to Mirrorman95 for example files.
 -2.95 - Added SetPreviewOption for plugin authors.
 -2.96 - When Noesis_GetMatData/Noesis_GetMatDataFromLists is called, if materials do not have external texture references, external diffuse references are created based on provided texture filenames.
 -2.96 - Further unicode support. (fixed some modules not being able to load related files from unicode paths, and issues with exporting to unicode paths)
 -2.97 - Added Noesis_SetModelAnims and Noesis_SetModelMaterials calls for plugin developers, which allow setting anim/material data after a model has already been generated.
 -2.97 - Added NANIMFLAG_FORCENAMEMATCH and NANIMFLAG_INVALIDHIERARCHY flags for animations, see comments in pluginshare.h for their uses.
 -2.97 - Added wide-char versions of various path string query/manipulation functions.
 -2.97 - Fixed a bug in the paired file loading which was introduced by 2.96 unicode changes.
 -2.97 - Added unicode file read/write plugin API functions.
 -2.97 - Fixed a potential bug with extracting archives on a widechar path.
 -2.98 - Added Noesis_FindOrAddMaterial for plugin developers, see comment in pluginshare.h for usage.
 -2.98 - Fixed FF10 models having more meshes than necessary.
 -2.98 - Made triangle sort occur on ConstructModel, so that mesh generation is optimized even when the Optimize function has not been called.
 -2.98 - Added Noesis_SetModelTriSort for plugin developers, and exposed a "Sort triangles" value in the data viewer. A value of 1 means sort by mesh, and sort triangles on a sub-mesh basis. A value of 2 means sort triangles regardless of batching. However, setting the value to 2 can destroy performance. (as it can produce thousands of draw calls)
 -2.981 - Quick change to no longer sort by default on constructModel, and add rpgConstructModelAndSort to do default sort instead. (default sort interrupted natural draw order and upset blending for a few formats)

Version 2.8-2.85:
 -Added support for the Kinect via OpenNI, accessible from the Tools menu. Requires a Kinect device, with working drivers and OpenNI installed.
 -Added "Open file" to File menu. (directly opens and browses to a specific file with the standard file picker)
 -Made smooth/dampen factor modifiable in the Kinect dialog, improved error handling in skeletal tracking. (added in 2.81)
 -Fixed animation matrices not being stored properly for identity-based Kinect recording setups. (added in 2.82)
 -Integrated ODE+IK support for Kinect recordings. (added in 2.82)
 -Fixed a possible timing issue with Kinect recordings. (added in 2.82)
 -Added brot and bmoda commands. (2.83)
 -Various in-progress stuff. (2.85)

Version 2.76:
 -Added ActorX PSK (model) import+export. Plugin source is included.
 -Added ActorX PSA (animation) import+export. Plugin source is included.
 -Added md5anim export.
 -Added support for animation sequences. Sequences can be viewed in isolation by selecting them in the data viewer.
 -Added "export from preview" option, which exports data directly from the preview model, incorporating any changes made by the data viewer.
 -Added BNR+U8 container support.
 -Exposed generic un-lzss function, which accepts many different decompression parameters.
 -Added a "show memory leaks" option to the tools menu. It is recommended that plugin authors enable this option.
 -Fixed a stack overflow when loading large PSK models, and sped up smoothed normal calculation by a factor of 10 or so.
 -Changed default vertex normal calculation method.
 -Fixed procedural geometry generator breaking meshes up based on vertex weights, when it didn't need to.

Version 2.64:
 -New class-based math library for plugin authors. It's completely optional and works with the existing C-based math library.
 -Refined math classes a bit and cleaned up the implementations.
 -Made rpgOptimize account for varying numbers of vertex weights and different vertex component bits.
 -Added -combinemeshes option.
 -Made COLLADA importer support non-triangle polygon lists.

Version 2.54:
 -Exposed a variety of compression/decompression methods through the plugin interface.
 -Added Metroid Prime 1/2/3 .PAK support via plugin. (source is included) Thanks to revelation for providing the info for this format!
 -Added GameCube/Wii filesystem support to the .iso parser.
 -Added FF7CC archive extraction support, changed FF7CC model extension.
 -Added extra wireframe rendering functionality to the data viewer.
 -Added Evangelion: Jo .pkg extraction support.
 -Various other fixes and minor additions that I couldn't be bothered to keep track of.

Version 2.42:
 -Added "Batch process" to the tools menu. Allows you to export multiple files and issue other arbitary processing commands.
 -Fixed a crash when exporting UV-less models to SMD.
 -Fixed another crash when exporting UV-less or normal-less models to OBJ.
 -Fixed texture output type sometimes not being recognized.

Version 2.35/2.36/2.37/2.38:
 -Fixed Bayonetta support up, and added Vanqish support in the same plugin module. (the formats are similar)
 -Fixed broken path names for FPK extraction, made TTD's auto-load with GMO's. (when applicable)
 -Made GMO not default to grouping by material. Old functionality can be invoked by the new -gmogroup option.
 -Various changes and fixes for the plugin system.
 -And yet more changes and fixes for the plugin system! Added auto-normalization of weights, and triangles with different vertex component bits will not be merged into the same surface.
 -Added the ability to rotate/translate bones with offsets from within the data viewer.

Version 2.3:
 -Added proper display of normal maps where applicable, and some new light properties. (viewable/editable in the data viewer)
 -Bayonetta model import support. Source code is included in the plugin SDK.
 -Sped model preview load up slightly. Probably won't be noticeable, this was mainly a forward-looking optimization.
 -Added vertex morph frame items for the data viewer. Highlighting a frame will render the model in that frame in the active preview.
 -Now sorting the file type mask in alphabetical order.
 -Various new plugin API functions, including some useful procedural animation functionality. (use it to test your bone weights)
 -Fixed another container bug that was causing .iso and .afs to not be correctly recognized.
 -Added CPK container extraction support. Thanks to hcs for releasing source code that describes this format! This implementation should run around 10-20 times faster than cpk_unpack.exe.

Version 2.2:
 -Export support for Quake II MD2, with new -md2strips and -md2painskin command line options. MD2 exporter plugin source has been updated. This rounds out import+export support for MDL, MD2, MD3, and MD5.
 -Fixed a bug causing extra vertex weights to sometimes not be initialized with NMSHAREDFL_FLATWEIGHTS_FORCE4.
 -Unified the way that model-with-builtin-animation export is handled. (the IQM plugin code has been updated accordingly)
 -Over 15 new RAPI functions for plugin development, exposing lots of new functionality, from tokenized text parsing to image resampling and combining. (see pluginshare.h, >= 2.2 API functions are commented)
 -Added -mdlavoidfb command line option to avoid fullbright colors when exporting Quake MDL skins.
 -Added -mdlskinsize command line option to explicitly set output dimensions of Quake MDL skins.

Version 2.1:
 -Quake MDL export support. This automatically combines texture pages and dithers them all to the Quake palette. It also bakes all available skeletal and vertex animation into the MDL frames.
 -Fixed a general archive bug, which was causing quite a few archive file types to not be correctly recognized.
 -Added another RAPI interface function (for plugins) which performs all commandline-specified transforms on a set of animation matrices. (plugins previously had no way to obey -rotate, -posoffset, etc. command line options for anim data)
 -Fixed a variety of transform (rotate/scale/offset) bugs, as some transform behavior was still format-dependent and it no longer is.

Version 2.0:
 -New plugin system. Plugins can import/export any model, texture, and/or animation format, and allow seamless third-party integration of new file formats into Noesis.
 -Plugin SDK is now included in pluginsource.zip. Each plugin project compiles in MS Visual Studio 2005, and they probably compile fine with the free Express Edition.
 -Quake II MD2 import support added via plugin. Source code is included.
 -PCX image import and export support added via plugin. Source code is included.
 -Inter-Quake Model import and export support added via plugin. Source code is included.
 -Added new control over scene lights. Highlight them in the data viewer to rotate them with the left mouse in the model view. Their pivot point and distance to pivot can also be adjusted directly in the data viewer.
 -Added support for extracting LithTech REZ files. (thanks to aluigi's bms script for the spec)

Version 1.9:
 -Corrected a texture load path bug with .noesis files.
 -Added support for extracting GCF (Valve) files. Tested with format version 1.6, support for other versions is questionable.
 -Added import support for Valve VTF textures. Only supports a limited set of image types, and was only tested with v7.1 images.
 -Added import support for Source MDL models. Only tested with format version 44.
 -Added import support for Quake MDL.
 -Added import support for FF8 battle models/animations.
 -Made HL .map support actually work again. (loads halflife.wad if it's in the working directory, to generate proper texcoords)
 -Changed default coordinate system for Heretic 2, SiN, and Q3A models.

Version 1.8:
 -Made MD3 export path handle NULL UV's.
 -Added import and export support for Heretic 2 .m8 textures.
 -Added import support for Heretic 2 .fm models. Vertex animations are handled, but reference/node/skeletal data is not.
 -Added support for paletted images in PNG and TGA loaders.
 -Added support for SiN variant of Quake PAK format.
 -Added import support for SiN SBM/SAM model/frame data.
 -New support for ".noesis" scene files. This is a text-based format which allows custom scenes to be crafted with simulated physics, but functionality is still limited. Two scenes are included, one of which references an implementation of the ODE physics library.

Version 1.7:
 -Generic vertex morph handling. Only implemented so far for Sub Culture's DFF format, DOAX2/NG2, and MD3. Preserves vertex morphs on export (to some formats) and displays them in previewer as animations.
 -Quake 3 MD3 import and export. (useful for exporting those morph target meshes, though there is usually precision loss in the format)
 -Fixed a path bug, which might've shown up in situations where a file is processed in a working-directory-relative path.
 -Support for converting skeletal models+animations to pure vertex morph animations, via the MD3 path. Bone-based tags are also supported. (see -md3tbone advanced option)

Version 1.6:
 -New "Special Thanks" section in ReadMe, as I realized I was being a thankless bastard for all of the awesome people on XeNTaX.
 -Fixed a .glm import bug, which would cause some surfaces to be missed entirely. (thanks to AceWell for submitting this bug)
 -Added global JPEG reading/writing. (did this mainly to have auto-loading for JK2 model textures)
 -Fixed another .glm bug, where path to .gla would be treated as working-directory-relative instead of file-relative.
 -Made scene lighting not rotate with model when changing the base rotation axis.
 -Added read support for very old RenderWare (I think) DFF format. (used in Sub-Culture for Windows/PC)
 -Added limited BMP read/write support. (24bpp with no RLE)
 -Fixed bad interface state when drag-and-dropping anims to apply to open models.

Version 1.5:
 -Fixed crash on attempting to export non-power-of-two DXT-compressed images to non-DXT formats. (thanks to firsak for submitting this bug)
 -Fixed NMD texture output stomping sequential files in some instances.
 -Fixed a potential crash when opening screwy SMD files. (thanks to firsak for submitting this bug)
 -Added "advanced commands" button to export window, to list export options.
 -Other things which have been lost in the pages of history.

Versions 1.0-1.4:
 -It's a mystery!

===============
Command Line Mode
===============
Noesis can be activated on the command line by using ?cmode as the first command line argument. This allows you to quickly process files from external batch files or other automation tools. Syntax is Noesis.exe ?cmode infile.raw outfile.raw -options. An example batch file to convert one SMD model to RDM, rotating it 90 degrees, scaling it up to 2x the size, and prefixing texture names with the given string:

@echo off
Noesis.exe ?cmode "pl_male01_hi.smd" "pl_male01_hi.rdm" -rotate 90 0 0 -smdnorm -scale 2.0 -texpre "male01 tex_"
pause

===============
Kinect Notes
===============
You're on your own when it comes to getting your connect set up and working with OpenNI, you'll just have to Google it. It's also possible that, by now, the Noesis OpenNI+Kinect implementation is broken. Probably not, but who knows!

That said, once you've got Noesis to recognize the device, you'll have to assume a "T-pose" with your arms sticking straight out, but also with your elbows bent so that your hands are pointing toward the ceiling. Consult the OpenNI/NITE documentation for more info, or go find my YouTube demo video and observe.

Setting models up to map to the generic NITE skeleton involves mapping bones. You can apply angle modifiers or flip specific axes, as needed. Most models will require you to tick the "global x flip" and "global y flip" options, but it depends on the coordinate system of the model you're working with.

Additionally, you can use the "Base cap" option to snap a pose of yourself attempting to mimic your model's base pose. This will then apply only base-relative matrices to the model's existing pose, rather than completely overriding. This option may mean less screwing around with angle offsets on certain models, but you shouldn't mess with it unless you've got a pretty good idea of what you're doing.

You can also record animation data directly into the preview model. After recording, you can export that animation data into any Noesis-exportable animation format, using the "Export from preview" option.

Oh, and you can save/load bone mappings in the form of .noekin files. If a .noekin file exists with the same name as your model file, it will be auto-loaded. Well, that about covers it. This is just crazy experimental functionality, so don't expect a lot from it.

===============
MDL Export Notes
===============
Noesis has some pretty in-depth functionality for exporting models to MDL/MD2/MD3/MD5, used by various id game engines. Here are some tips on using that functionality.

-For MD2, pay attention to the "Skin path:" printout at the end of your export. Skin paths need to be absolute to work in Quake II, so you may need to add something alone the lines of -texpre /models/monsters/infantry/ to your advanced options. (only as an example, you should replace the infantry path with wherever your skinpage.pcx will end up)
-For MDL, you will probably want to use -mdlavoidfb in the advanced options, if you want your model to look correct in software and you have not custom-crafted a Quake palette for it.
-The -mdlskinsize advanced option will work for both MDL and MD2 texture output.
-MD3 allows you to specify any bone in your import model as a tag on export - see the -md3tbone option.
-MDL, MD2, and MD3 are all generally interchangeable in terms of data they import/export. The main things to note are the potential loss of vertex/texture coordinate precision and MD3 tags.
-All MD* formats can also bake skeletal animation data out to their vertex frames. This happens automatically when you convert a model with skeletal animation data. You can also use -loadrda to load pre-generated RDA animation files and combine them with static skeletal meshes. (the results will be baked into the MDL/MD2/MD3)
-The MDL and MD2 exporters automatically generate a single texture page from all textures that the model being converted references, compensating the texture coordinates in the model. This can be incredibly handy, since MDL and MD2 only allow a single texture page to be referenced. Texture pages can be grabbed from within your source model, and on the local path in any image format that Noesis supports. Just remember to have your textures all in the same folder as the model being imported/exported.

===============
Special Thanks
===============
revelation:
 -Provided me with various specs and education on VIFcode and lots of other PS2-related stuff.
 -Provided spec for the FFX model/animation formats!
 -Continually put up with my dumb questions about FFX animations.
 -Provided info on the FFX filesystem.
 -Provided Metroid Prime .pak file info.
 -Also assisted in the Capcom .mod format and made many of his findings public, which assisted me in conjunction with Surveyor's efforts.
 -Yet another awesome guy that is always popping up whenever there are models to be discovered.

Mr.Mouse:
 -Hosts Noesis and its site!
 -Active admin and founder of XeNTaX! (we're not worthy)
 -Without his efforts toward XeNTaX, Noesis may never have been born.

aluigi:
 -Cracked encryption on Ys: The Oath in Felghanna archives, which allowed me to get at the .ymo data with ease.
 -Provided spec on the LithTech .rez files.
 -I'm not sure what else, but he's constantly figuring out compression/encryption methods for various games, and he rules.

Surveyor:
 -Made public most of the ground work for the Capcom .mod format, and saved me hours (maybe even days) of hex-editing!
 -Is also generally awesome, and has tackled countless model formats on XeNTaX.

Tomaz:
 -Hangs out in #qc and randomly shows interest in data decyphering. Helped with Sub-Culture stuff too.

chrrox:
 -I don't remember exactly, but I know he's sent me a lot of stuff privately and has generally been a great help.
 -Can routinely be seen writing MaxScript importers for a variety of model formats.

===============
Rights of Use
===============
The author of this software, Rich Whitehouse, accepts no liability for any use (intended or otherwise) of this software, and expressly forbids the use of this software in violating any form of intellectual or copyright law.

Noesis is provided free of charge and as a NON-COMMERCIAL product, and may not be used or distributed in attachment to any commercial or copyrighted product. Noesis also may not be distributed without this ReadMe.txt file included in completely unmodified form.

Many file formats supported by Noesis are also used in commercial products. When working with existing material, make sure you know your usage rights, and do not redistribute any copyrighted content that doesn't belong to you!

The author of this software does not in any way condone or support copyright violation/infringement.

Plugins for this program are not supported or guaranteed in any way, and the author of this software is not responsible for any aspect of third-party plugins. Use caution when using plugins, and please be responsible and adhere to legal practices when writing them.

Improper or uninformed use of Noesis could cause serious harm to you or your computer. The author of this software accepts no responsibility for any damages which result from the use of this software. You use this software entirely at your own risk.

Additionally, Noesis makes use of libjpeg for JPEG reading/writing, as well as zlib for... lots of things. Oh, and FCollada for COLLADA reading/writing. And libpng for PNG reading/writing, as well as GIFLIB for GIF reading/writing. It also implements Python through a plugin that links to the Python C library. As of version 3.75, a modified and slimmed down version of libcurl is also used for HTTP transfers. I think that covers all of the third-party libs.

===============
Uninstalling
===============
If you want to wipe all traces of Noesis from your system, first remember to use the association dialog under the Tools menu to remove all associations with file types on your system. Then delete the HKEY_CURRENT_USER\Software\Noesis key in your registry. You can then delete the actual folder in which you have extracted the Noesis files.
An automated installer/uninstaller may be supplied some day, when the author is less lazy.

===============
Trouble!
===============
If something goes wrong, first try removing all of your third-party plugins. If the problems go away after removing those plugins, try adding them back one at a time. Once you find the plugin causing the problem, contact the author of that plugin and tell him/her that his/her plugin is busted.

If the problems don't go away after removing your plugins, you can post in the Noesis tool thread on XeNTaX. Try to read through the thread and see if anyone else has had the problem first, though.

Additionally, if your problem appears to be on export to a specific format that doesn't appear right when imported into another tool, try importing it back into Noesis. If it looks right in Noesis, there's a pretty good chance the fault is actually in the other program's importer and not Noesis's exporter. In this case, you should contact the author(s) of that other program and/or its import plugin.

If you have trouble using a plugin, such as the plugin not seeming to load or add the given format to the format list, make sure you have the latest MSVC++ 2005 redistributable package installed. As of this writing, it can be found here: http://www.microsoft.com/download/en/details.aspx?displaylang=en&id=3387

===============
Making Plugins
===============
For information on writing Python scripts, see "plugins\python\__NPReadMe.txt".

For native binary plugins, a file called pluginsource.zip is included in the Noesis distribution. It contains all of the source code you will need to create your own Noesis plugins, with examples in the form of code for some of the plugins that come with the program. Each plugin is made to compile in MS Visual Studio 2005, and should upgrade to newer Visual Studio versions automatically with no issues. Some best-practices to keep in mind when writing plugins:

1) Use 1-byte struct alignment for all shared structures. (example plugin MSVC project files default everything to 1-byte-aligned)

2) Always clean up after yourself. Your plugin stays in memory the entire time Noesis is loaded, so you don't want to crap up the process heaps. Some API functions/interfaces use pooled allocations, which you don't need to free. However, you should take special care to free data when the function's comment tells you it's passing unpooled memory back to you, or when you're doing your own local heap allocations.

3) Try to use reliable type-checking, to ensure your plugin doesn't conflict with other file types and create false-positive situations.

4) Really try not to write crash-prone logic in your data check function! This could lead to Noesis crashing from trivial things like the user browsing files.

5) When using the rpg begin/end interface, always make your Vertex call last, as it's the function which triggers a push of the vertex with its current attributes. Look at the existing plugin examples for good example usage of the rpg interface.

6) When compiling in Visual Studio, it's best to include _USE_RTM_VERSION in the preprocessor list, to ensure good runtime dependencies. Alternatively, you can statically link to the runtime library in your DLL, but this is generally a bad idea and will bloat your binary size.

7) Any C++ compiler can be used to make Noesis plugins. Just make sure you export the NPAPI functions listed in noesisplugin.def, and that you use 1-byte struct alignment (at least for all API-related structures). It's also possible to produce plugins in C, because the core Noesis interface is C-compatible. You would need to insert some #ifdefs in your copy of pluginshare.h to accomplish this, however.

8) It's possible, and relatively easy, to write a Noesis plugin which adds support for new kinds of scripts and scripting languages, like Python. An example implementation might be structured like this:
 -Plugin loads, initializes interpreter, scans for scripts in a given directory, and parses them. The scripts can add their own filetypes via the plugin's interpreter implementation, with the interpreter implementing builtins to allow scripts to call back in through g_nfn->NPAPI_Register.
 -Plugin implements stub functions for file handlers (g_nfn->NPAPI_SetTypeHandler_TypeCheck, g_nfn->NPAPI_SetTypeHandler_LoadModel, etc.), which actually call into script implementations for model, animation, package, etc. loading.
 -Plugin provides builtin interpreter interfaces to mirror the Noesis API. Because new versions of Noesis never break API compatibility, you don't have to worry about your interpreter interface breaking. It will only lack new functionality added in new Noesis versions, until you get around to updating it.
