IF you use any of my object I made in this .ed, I made these for
 your use but I want some credit! dammnit! Anyway there is a lot
 of shiot in this .ed that you can use. all I want is some credit
 for my work. 

hell all you have to do is say something like...
 the mine cart was made by smoth (natrolite@hotmail.com)
I have alot of useful items in here. so use them please
 they are cool but I have no use for them so, give them
 a home please

-Steven (Smoth) Smith

and before I gat any dumb assed e-mails about how to copy this shiot...
1. select the node for the chosen object.
2 change windows to the desired map and paste the mofo
(if will not work IF you close shapes .ed while pasting hell if I know why.)

soanyway that is the low down so here partake of the fruit, just remember 
that I gave it to you and remember to give proper thanks. // gotta have something funny in here.


btw, monolith doesn't support dedit and stuff so don't
 bother them just bother me about the contents of this zip..