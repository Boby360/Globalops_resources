Soundpack for Global Operations v4.0 - www.globalopsgame.com

Here is a neat little sound pack v4.0 for Global Ops. Included are over 85 sounds (hey who's counting?)

To install, simply extract each file into your: 

C:/program files/Crave/globaloperations/globalops/sounds

So if you want the radio sounds, extract the radio pack into:

C:/program files/Crave/globaloperations/globalops/sounds/radio

PUT EACH PACK INTO ITS PROPER FOLDER
-------------------------------------------------------------
Listen to each sound to make sure you like them. I don't have the default
sounds so if you aren't careful in picking the sounds you like, don't come
crying to me.
-------------------------------------------------------------

*NOTE: I DID NOT MAKE THESE SOUNDS. All of these sounds were taken from various
soundpacks I found on the net. All I did was just fit them to work in Global Ops.

Some sounds, but not all, are from:

http://csnation.counter-strike.net/custom-section/ghost_recon.htm

Many others are from Kaebaek from:

Killers for Hire Counter-Strike Team
www.killers4hire.com

Also, I think a few are from HK - http://hksound.cjb.net/

Some more are from Defcon: www.d1uk.net/code1

And I used a bunch of sounds taken from different weapon models in a bunch
of custom models websites websites I went to.
-------------------------------------------------------------

If any of the above people have a problem with this soundpack, let me know.

Have fun! If you have any questions, email them to demoman@myself.com.
If you have any hate mail, send it to: iamsofaking@wetodddid ;)

-pain (former www.globalopscommand.net staff member)































