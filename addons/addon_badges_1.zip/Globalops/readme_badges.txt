Fallout <falloutdc at gmail dor com>
fallout.bplaced.net

Addon Badges for in game use

Compilation of handmade badges some from early beta versin of game, some from exisitng pack and some where added in 2012
