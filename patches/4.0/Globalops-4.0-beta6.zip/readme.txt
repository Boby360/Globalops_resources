History
=======

4.0 - [05-07-2023] - Unofficial update

New features
============

-updated the Network speed with higher values, more packets are send to the client
-removed the Network speed settings of 56k and ISDN
-renamed the settings to LOW, MEDIUM, HIGH and VERY HIGH
 
-added the following values to:
 LOW - (15) same value as the old DSL setting
 MEDIUM - (20) same value as the old T1+ setting
 HIGH - (25) new value
 VERY HIGH - (30) new value

-added high resolution timing code to both the client and server executable
-added a FPS limiter to fix the warping problems and weird NPC behaviour
-changed the client and server files to version 1.40.0.0

Bug fixes
=========

-changed the discontinued GameSpy server to OpenSpy
-changed the GameSpy graphics to OpenSpy


3.51 - [09-05-2007]

-Fixed the Windows server with regards to 'weird characters' appearing on the console

3.5 - [08-05-2007] - minor update

-Fixed crashes under Windows 2000, Windows XP SP1 and Windows Vista

3.5 - [28-04-2007] - Unofficial update

New features
============
-added new anti-cheat functions into the client files.
-updated the client files to version 1.29.0.0

Bug fixes
=========
-added favorite_servers.txt
-added missing world sound file in Chechnya (levelspec_caveindebris03.wav)
-added missing world sound file in Chechnya (levelspec_machinerunning.wav)
-added missing texture file in Mexico (detailgrey_detail_01a.dtx)
-added missing mission briefing texture in Tunnel (tunnel.dtx)
-added missing missionbriefing texture in Uganda (uganda.dtx)
-several fixes in the scripts

-Fixes in animation.txt
 added missing seperators [ , ] at death crouch animation values
 added missing seperators [ , ] at player and hostage walk strafe left animation
 corrected type errors in death animation
 changed hostage strafe animation so it should follow beter
 changed player jump animation against floating/bunny hopping players

-Fixes in animspecialty.txt
 added missing seperators [ , ] at player and vip walk strafe left animation
 changed the bm_run animation for all classes to a fixed animation
 changed jump animation against floating/bunny hopping players

-Fix in animequip.txt
 added "drop" value for the objectives of Antartica and Argentina 

Map Fixes
=========

-Quebec
 VIP (Goran Kurcic) can not be killed anymore by both teams
-Colombia
 VIP (Jesus Ortiz) can not be killed anymore by own team
 VIP (Jesus Ortiz) corrected MaxHealth to the same value as StartHealth
-Chechnya
 VIP (Commander Gredano) can not be killed anymore by own team
-SouthChinaSea
 corrected deathzone`s at pirates spawnside
-SriLanka
 changed TransportSight to 3000 (helicopter does not kill people behind templewall anymore)
 removed ground under rocks
 added invisible walls which block access to exploitable area`s
 added spawnguard at VLF second spawn
 changed highed of front templewall
 changed highed of towerwalls

2.1 - [04-06-2002] - Server side only

Bug fixes
=========

-Logging stops after 20+ hours.
-Message of the day disappears after 20+ hours.

New features
============

-Turn off the anti-speed hack code within the server application


2.0 - [13.05.2002]

Bug fixes
=========

-Server crash when using the LAW.
-Linux server optimizations and bug fixes.
-No sight when using NV/TV goggles.
-Cursor disappears when on exit menu at end of round.
-HUD on/off not saving correctly.
-Server crash after adjusting mirror damage.
-Hide in rock on Sri Lanka.
-Jumping off boat in South China Seas.
-The muzzle flash not appearing in correct location.
-Some shots were getting lost.
-Friendly fire setting affecting the VIP issue.
-You can no longer shoot your own VIP and win the round.
-Grenade issues.
-Reload problem.
-Jiggies/warping problems (this is the anti cheat code acting up).
-Heavy Machine guns now no longer give you one more round after a reload.
-Teammates almost never appear in the spectate mode.
-Laser sight not working properly.
-Secondary fire for remote C4 doesn't toggle from the switch back to the next charge.
-Smoke trail on LAW and Grenade Launcher disappears as soon as the warhead detonates.
-Blood squirt alignment.
-Eyes removed when player gets too many damage decals.
-Kills register as suicides sometimes.
-Missing sound in Chechnya.
-LAW rocket is rotated wrong when fired on extreme angles.
-Another gas mask crash.

New features
============

-Remote server admin including kicking and banning.
-In game voting for kicking and map rotation.
-You can now choose favorite servers.
-Refresh favorite servers.
-New set of filters.
-Server browser distinguishes the different game versions (eg: White=compatible)
-AFK kick as a server side option.
-IP banning as a server side option.
-Improvement to best weapon selection code.
-Shooting your teammates will cost you money. (no more medic cheat to get cash)
-Server side option to force balanced teams when you join.
-Tac map shows enemies when they are outside.
-Network Connection speed moved to browser screen.


1.2 [04-11-2002]

Bug fixes
=========

-Client freeze at round end.
-Server crash when allied teams kill NPC`s.
-Mouse zoom bug.
-Gas/smoke grenade sprite bug.
-C4 bomb pick up issue.
-Other stability fixes.


1.1 - [01.04.2002]

Bug fixes
=========

-Server has been fixed so that client side speed hacks do not work.
-Reload bug (probably fixed).
-Remote C4, various bugs.
-AW50 has correct damage values.
-Gas grenade/gas mask lockup.
-Random client freezes.
-Gas no longer effects users on next round.
-Purchase screen, fixed bug where users were unable to buy items when they have enough money.
-Grenades existing on client but not server (they persist until the client dies).
-Vision enhancements could get out of sync with server.
-Vision enhancements gave inconsistent results while zoomed.
-LCD screen on view model timed C4 is now full bright.
-Pain sounds from damage brushes cause a pain sound every time health goes down.
-Grenade launcher accuracy matches crosshair, tweak of accuracy values.
-Green question mark.
-Joining level late, destructible models not there.
-Added locked server info to browser.
-Moved network connection speed switch to browser window.
-Added missing sound files for frontend and flash grenade.
-Tweaks to player prediction code.
-Server upload bandwidth spikes when players join
-Duplicate clients appeared in spectator/IO mode.
-Scrollbar thumb control could shrink to tiny sizes.
-Upload speed switch added to server.
-Servers report score to gamespy correctly now.
-Servers report their shutdown correctly to gamespy now.